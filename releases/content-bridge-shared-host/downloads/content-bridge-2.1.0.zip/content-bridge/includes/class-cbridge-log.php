<?php
/**
 * لاگ عملیات — منبع شمارش سقف نرخ هم همین است.
 *
 * @package Content_Bridge
 */

defined( 'ABSPATH' ) || exit;

/** ثبت و خواندن رویدادها. */
class CBridge_Log {

	/**
	 * نام جدول.
	 *
	 * @return string
	 */
	public static function table() {
		global $wpdb;
		return $wpdb->prefix . 'cbridge_log';
	}

	/** ساخت/به‌روزرسانی جدول. */
	public static function install_table() {
		global $wpdb;
		$table   = self::table();
		$collate = $wpdb->get_charset_collate();

		// ایندکس (action, created_at) عمدی است: سقف نرخ از همین می‌خواند.
		$sql = "CREATE TABLE {$table} (
			id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
			action VARCHAR(50) NOT NULL DEFAULT '',
			external_id VARCHAR(191) NOT NULL DEFAULT '',
			post_id BIGINT UNSIGNED NULL,
			ip VARCHAR(45) NOT NULL DEFAULT '',
			status SMALLINT NOT NULL DEFAULT 0,
			message TEXT NULL,
			created_at DATETIME NOT NULL,
			PRIMARY KEY (id),
			KEY action_time (action, created_at),
			KEY ext (external_id)
		) {$collate};";

		require_once ABSPATH . 'wp-admin/includes/upgrade.php';
		dbDelta( $sql );
	}

	/**
	 * ثبت یک رویداد. توکن هرگز اینجا نوشته نمی‌شود.
	 *
	 * @param string   $action  نوع رویداد.
	 * @param int      $status  کد وضعیت HTTP.
	 * @param string   $message پیام کوتاه.
	 * @param string   $ext     شناسه‌ی بیرونی.
	 * @param int|null $post_id شناسه‌ی پست.
	 */
	public static function add( $action, $status = 200, $message = '', $ext = '', $post_id = null ) {
		global $wpdb;
		$wpdb->insert(
			self::table(),
			array(
				'action'      => substr( (string) $action, 0, 50 ),
				'external_id' => substr( (string) $ext, 0, 191 ),
				'post_id'     => $post_id ? (int) $post_id : null,
				'ip'          => self::ip(),
				'status'      => (int) $status,
				'message'     => substr( (string) $message, 0, 2000 ),
				'created_at'  => gmdate( 'Y-m-d H:i:s' ),
			),
			array( '%s', '%s', '%d', '%s', '%d', '%s', '%s' )
		);
	}

	/**
	 * شمارش رویدادها در یک بازه — پایه‌ی سقف نرخ.
	 *
	 * وابسته به دیتابیس است نه transient: روی object-cache یا هاست اشتراکی
	 * که پردازه idle-kill می‌شود، transient بی‌صدا صفر می‌شود و سقف بی‌اثر.
	 *
	 * @param string $action  نوع رویداد.
	 * @param int    $seconds بازه به ثانیه.
	 * @return int
	 */
	public static function count_since( $action, $seconds = HOUR_IN_SECONDS ) {
		global $wpdb;
		$table = self::table();
		return (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$table} WHERE action = %s AND created_at > %s", // phpcs:ignore WordPress.DB.PreparedSQL
				$action,
				gmdate( 'Y-m-d H:i:s', time() - (int) $seconds )
			)
		);
	}

	/**
	 * آخرین ردیف‌ها برای نمایش در پنل.
	 *
	 * @param int    $limit  تعداد.
	 * @param string $filter فیلتر روی action.
	 * @return array<int,object>
	 */
	public static function recent( $limit = 50, $filter = '' ) {
		global $wpdb;
		$table = self::table();
		$limit = max( 1, min( 200, (int) $limit ) );

		if ( $filter ) {
			return (array) $wpdb->get_results(
				$wpdb->prepare(
					"SELECT * FROM {$table} WHERE action = %s ORDER BY id DESC LIMIT %d", // phpcs:ignore WordPress.DB.PreparedSQL
					$filter,
					$limit
				)
			);
		}
		return (array) $wpdb->get_results(
			$wpdb->prepare( "SELECT * FROM {$table} ORDER BY id DESC LIMIT %d", $limit ) // phpcs:ignore WordPress.DB.PreparedSQL
		);
	}

	/** حذف ردیف‌های قدیمی‌تر از تنظیم. */
	public static function prune() {
		global $wpdb;
		$days = (int) cbridge_opt( 'log_days' );
		if ( $days < 1 ) {
			return;
		}
		$table = self::table();
		$wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$table} WHERE created_at < %s", // phpcs:ignore WordPress.DB.PreparedSQL
				gmdate( 'Y-m-d H:i:s', time() - $days * DAY_IN_SECONDS )
			)
		);
	}

	/**
	 * IP درخواست‌کننده — فقط برای لاگ.
	 *
	 * @return string
	 */
	private static function ip() {
		$ip = isset( $_SERVER['REMOTE_ADDR'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REMOTE_ADDR'] ) ) : '';
		return substr( $ip, 0, 45 );
	}
}
