<?php
/**
 * منطق مشترک ساخت/به‌روزرسانی پست — REST و AJAX هر دو از همین استفاده می‌کنند.
 *
 * @package Content_Bridge
 */

defined( 'ABSPATH' ) || exit;

/** پردازش payload و ساخت پست. */
class CBridge_Handler {

	const META_EXT = '_cbridge_external_id';

	/**
	 * پیداکردن پست موجود از روی شناسه‌ی بیرونی.
	 *
	 * @param string $ext شناسه.
	 * @return int 0 اگر نبود.
	 */
	public static function find_by_external( $ext ) {
		if ( '' === $ext ) {
			return 0;
		}
		$found = get_posts(
			array(
				'post_type'        => 'any',
				'post_status'      => 'any',
				'numberposts'      => 1,
				'fields'           => 'ids',
				'meta_key'         => self::META_EXT, // phpcs:ignore WordPress.DB.SlowDBQuery
				'meta_value'       => $ext,           // phpcs:ignore WordPress.DB.SlowDBQuery
				'suppress_filters' => false,
			)
		);
		return ! empty( $found ) ? (int) $found[0] : 0;
	}

	/**
	 * نویسنده را پیدا کن.
	 *
	 * @param array $author آرایه‌ی name/email.
	 * @return int
	 */
	private static function resolve_author( $author ) {
		if ( ! empty( $author['email'] ) ) {
			$user = get_user_by( 'email', $author['email'] );
			if ( $user ) {
				return (int) $user->ID;
			}
		}
		if ( ! empty( $author['name'] ) ) {
			$users = get_users(
				array(
					'search'         => $author['name'],
					'search_columns' => array( 'display_name', 'user_nicename', 'user_login' ),
					'number'         => 1,
					'fields'         => 'ID',
				)
			);
			if ( ! empty( $users ) ) {
				return (int) $users[0];
			}
		}

		$fallback = (int) cbridge_opt( 'default_author' );
		if ( $fallback && get_userdata( $fallback ) ) {
			return $fallback;
		}

		$admins = get_users(
			array(
				'role'   => 'administrator',
				'number' => 1,
				'fields' => 'ID',
			)
		);
		return ! empty( $admins ) ? (int) $admins[0] : 0;
	}

	/**
	 * پردازش کامل یک درخواست.
	 *
	 * ترتیب مراحل عمدی است — مخصوصاً ثبت external_id بلافاصله بعد از ساخت
	 * پست و پیش از رسانه/سئو: اگر مرحله‌ای بعدش بشکند، اجرای بعدی همین پست
	 * را کامل می‌کند به‌جای اینکه پست دوم بسازد.
	 *
	 * @param array $raw ورودی خام.
	 * @return array{status:int,body:array}
	 */
	public static function process( $raw ) {
		$check = CBridge_Validator::check( $raw );
		if ( ! $check['ok'] ) {
			CBridge_Log::add( 'post.invalid', 400, implode( ' | ', $check['errors'] ), $raw['external_id'] ?? '' );
			return array(
				'status' => 400,
				'body'   => array(
					'ok'     => false,
					'code'   => 'invalid_input',
					'errors' => $check['errors'],
				),
			);
		}

		$d        = $check['data'];
		$warnings = $check['warnings'];

		// ── حالت: ساخت یا به‌روزرسانی ──
		$existing = self::find_by_external( $d['external_id'] );
		$is_update = $existing > 0;

		// ── تنزل امن: تا فلگ روشن نشود، هیچ‌چیز منتشر نمی‌شود ──
		$status     = $d['status'];
		$downgraded = false;
		if ( 'draft' !== $status && 1 !== (int) cbridge_opt( 'allow_publish' ) ) {
			$status     = 'draft';
			$downgraded = true;
			$warnings[] = 'انتشار مستقیم در تنظیمات خاموش است؛ مطلب به‌صورت پیش‌نویس ذخیره شد.';
		}

		$postarr = array(
			'post_type'    => $d['post_type'],
			'post_title'   => $d['title'],
			'post_content' => $d['content'],
			'post_excerpt' => $d['excerpt'],
			'post_status'  => $status,
			'post_author'  => self::resolve_author( $d['author'] ),
		);
		if ( $d['slug'] ) {
			$postarr['post_name'] = $d['slug'];
		}
		if ( $d['date'] ) {
			$postarr['post_date_gmt'] = $d['date'];
			$postarr['post_date']     = get_date_from_gmt( $d['date'] );
		}

		if ( $is_update ) {
			$postarr['ID'] = $existing;
			$post_id       = wp_update_post( $postarr, true );
		} else {
			$post_id = wp_insert_post( $postarr, true );
		}

		if ( is_wp_error( $post_id ) || ! $post_id ) {
			$msg = is_wp_error( $post_id ) ? $post_id->get_error_message() : 'خطای ناشناخته';
			CBridge_Log::add( 'post.error', 500, $msg, $d['external_id'] );
			return array(
				'status' => 500,
				'body'   => array(
					'ok'    => false,
					'code'  => 'wp_error',
					'error' => $msg,
				),
			);
		}

		// ── شناسه‌ی بیرونی، بلافاصله. ضامن ضدتکرار. ──
		update_post_meta( $post_id, self::META_EXT, $d['external_id'] );

		// ── تکسونومی ──
		$terms_created = array();
		$cats = CBridge_Taxonomy::resolve( $d['categories'], 'category' );
		if ( ! empty( $cats['ids'] ) ) {
			wp_set_post_terms( $post_id, $cats['ids'], 'category', false );
		}
		$terms_created = array_merge( $terms_created, $cats['created'] );
		$warnings      = array_merge( $warnings, $cats['warnings'] );

		$tags = CBridge_Taxonomy::resolve( $d['tags'], 'post_tag' );
		if ( ! empty( $tags['ids'] ) ) {
			wp_set_post_terms( $post_id, $tags['ids'], 'post_tag', false );
		}
		$terms_created = array_merge( $terms_created, $tags['created'] );
		$warnings      = array_merge( $warnings, $tags['warnings'] );

		// ── تصویر شاخص ──
		$featured = 0;
		if ( $d['featured_image'] ) {
			$media    = CBridge_Media::attach( $d['featured_image'], $post_id );
			$featured = $media['id'];
			$warnings = array_merge( $warnings, $media['warnings'] );
		}

		// ── سئو ──
		$seo_res  = CBridge_Seo::write( $post_id, $d['seo'] );
		$warnings = array_merge( $warnings, $seo_res['warnings'] );

		// ── FAQ ──
		CBridge_Faq::save( $post_id, $d['faq'] );

		// ── متای دلخواه ──
		foreach ( $d['meta'] as $k => $v ) {
			update_post_meta( $post_id, $k, $v );
		}

		CBridge_Log::add(
			$is_update ? 'post.update' : 'post.create',
			$is_update ? 200 : 201,
			$d['title'],
			$d['external_id'],
			$post_id
		);

		return array(
			'status' => $is_update ? 200 : 201,
			'body'   => array(
				'ok'               => true,
				'action'           => $is_update ? 'updated' : 'created',
				'id'               => (int) $post_id,
				'external_id'      => $d['external_id'],
				'status'           => get_post_status( $post_id ),
				'downgraded'       => $downgraded,
				'link'             => get_permalink( $post_id ),
				'edit_link'        => get_edit_post_link( $post_id, 'raw' ),
				'featured_media'   => (int) $featured,
				'terms_created'    => array_values( $terms_created ),
				'content_stripped' => (bool) $d['content_stripped'],
				'seo_written'      => array_merge(
					array( 'plugin' => $seo_res['plugin'] ),
					$seo_res['written']
				),
				'warnings'         => array_values( array_unique( $warnings ) ),
			),
		);
	}

	/**
	 * فهرست سبک مطالب — برای گارد تکرار سمت کلاینت.
	 *
	 * external_id حتماً برمی‌گردد؛ نبودش باعث تشخیص غلط سمت کلاینت می‌شود.
	 *
	 * @param int    $limit تعداد.
	 * @param string $ptype نوع پست.
	 * @return array
	 */
	public static function listing( $limit = 50, $ptype = '' ) {
		$limit = max( 1, min( 200, (int) $limit ) );
		$types = $ptype ? array( $ptype ) : (array) cbridge_opt( 'post_types' );

		$posts = get_posts(
			array(
				'post_type'   => $types,
				'post_status' => array( 'publish', 'draft', 'future', 'pending' ),
				'numberposts' => $limit,
				'orderby'     => 'date',
				'order'       => 'DESC',
			)
		);

		$out = array();
		foreach ( $posts as $p ) {
			$out[] = array(
				'id'            => (int) $p->ID,
				'external_id'   => (string) get_post_meta( $p->ID, self::META_EXT, true ),
				'title'         => $p->post_title,
				'slug'          => $p->post_name,
				'status'        => $p->post_status,
				'date'          => $p->post_date_gmt,
				'link'          => get_permalink( $p ),
				'has_thumbnail' => (bool) has_post_thumbnail( $p->ID ),
			);
		}
		return $out;
	}
}
