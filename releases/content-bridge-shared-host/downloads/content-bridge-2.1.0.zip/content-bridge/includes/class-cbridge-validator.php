<?php
/**
 * اعتبارسنجی و پاکسازی ورودی.
 *
 * @package Content_Bridge
 */

defined( 'ABSPATH' ) || exit;

/** بررسی payload ورودی. */
class CBridge_Validator {

	/**
	 * ورودی را اعتبارسنجی و نرمال کن.
	 *
	 * قاعده: فیلد اجباریِ نامعتبر → خطا و هیچ پستی ساخته نشود.
	 * فیلد اختیاریِ نامعتبر → هرگز کل درخواست را نشکند؛ در warnings برود.
	 *
	 * @param array $d ورودی خام.
	 * @return array{ok:bool,errors:array,warnings:array,data:array}
	 */
	public static function check( $d ) {
		$errors   = array();
		$warnings = array();
		$out      = array();

		// ── external_id (اجباری، کلید ضدتکرار) ──
		$ext = isset( $d['external_id'] ) ? trim( (string) $d['external_id'] ) : '';
		if ( '' === $ext ) {
			$errors[] = 'external_id الزامی است.';
		} elseif ( ! preg_match( '/^[A-Za-z0-9._-]{1,191}$/', $ext ) ) {
			$errors[] = 'external_id فقط حروف/عدد و . _ - و حداکثر ۱۹۱ کاراکتر.';
		}
		$out['external_id'] = $ext;

		// ── title (اجباری) ──
		$title = isset( $d['title'] ) ? sanitize_text_field( (string) $d['title'] ) : '';
		if ( mb_strlen( $title ) < 2 ) {
			$errors[] = 'عنوان خالی یا خیلی کوتاه است.';
		} elseif ( mb_strlen( $title ) > 255 ) {
			$errors[] = 'عنوان بیش از ۲۵۵ کاراکتر است.';
		}
		$out['title'] = $title;

		// ── content (اجباری، بعد از kses هم باید بماند) ──
		$raw_content = isset( $d['content'] ) ? (string) $d['content'] : '';
		$clean       = wp_kses_post( $raw_content );
		if ( '' === trim( wp_strip_all_tags( $clean ) ) ) {
			$errors[] = 'محتوا خالی است (یا کاملاً توسط sanitizer حذف شد).';
		}
		$out['content'] = $clean;

		// افت بیش از ۵٪ یعنی چیزی حذف شده؛ باید گزارش شود نه خاموش بماند.
		$before = mb_strlen( $raw_content );
		$after  = mb_strlen( $clean );
		$out['content_stripped'] = ( $before > 0 && ( ( $before - $after ) / $before ) > 0.05 );
		if ( $out['content_stripped'] ) {
			$warnings[] = 'بخشی از HTML توسط wp_kses_post حذف شد — تگ‌های غیرمجاز را بررسی کنید.';
		}

		// ── status ──
		$status = isset( $d['status'] ) ? (string) $d['status'] : 'draft';
		if ( ! in_array( $status, array( 'publish', 'draft', 'future' ), true ) ) {
			$errors[] = 'status فقط publish یا draft یا future.';
			$status   = 'draft';
		}
		$out['status'] = $status;

		// ── post_type ──
		$allowed = (array) cbridge_opt( 'post_types' );
		$ptype   = isset( $d['post_type'] ) ? sanitize_key( (string) $d['post_type'] ) : 'post';
		if ( ! in_array( $ptype, $allowed, true ) ) {
			$errors[] = sprintf( 'نوع پست «%s» مجاز نیست.', $ptype );
		}
		$out['post_type'] = $ptype;

		// ── slug / excerpt / date ──
		$out['slug']    = isset( $d['slug'] ) ? sanitize_title( (string) $d['slug'] ) : '';
		$out['excerpt'] = isset( $d['excerpt'] ) ? sanitize_textarea_field( (string) $d['excerpt'] ) : '';

		$out['date'] = '';
		if ( ! empty( $d['date'] ) ) {
			$ts = strtotime( (string) $d['date'] );
			if ( $ts ) {
				$out['date'] = gmdate( 'Y-m-d H:i:s', $ts );
			} else {
				$warnings[] = 'تاریخ نامعتبر بود و نادیده گرفته شد.';
			}
		}
		if ( 'future' === $status && '' === $out['date'] ) {
			$errors[] = 'برای status=future باید date معتبر بدهید.';
		}

		// ── نویسنده ──
		$out['author'] = array(
			'name'  => isset( $d['author']['name'] ) ? sanitize_text_field( (string) $d['author']['name'] ) : '',
			'email' => isset( $d['author']['email'] ) ? sanitize_email( (string) $d['author']['email'] ) : '',
		);

		// ── تکسونومی ──
		foreach ( array( 'categories', 'tags' ) as $tax_key ) {
			$list = isset( $d[ $tax_key ] ) && is_array( $d[ $tax_key ] ) ? $d[ $tax_key ] : array();
			if ( count( $list ) > 20 ) {
				$errors[] = sprintf( '%s بیش از ۲۰ آیتم دارد.', $tax_key );
				$list     = array_slice( $list, 0, 20 );
			}
			$out[ $tax_key ] = array_values(
				array_filter(
					array_map(
						function ( $t ) {
							return sanitize_text_field( trim( (string) $t ) );
						},
						$list
					)
				)
			);
		}

		// ── تصویر شاخص (اختیاری) ──
		$out['featured_image'] = null;
		if ( ! empty( $d['featured_image'] ) && is_array( $d['featured_image'] ) ) {
			$img = $d['featured_image'];
			$out['featured_image'] = array(
				'base64'   => isset( $img['base64'] ) ? (string) $img['base64'] : '',
				'url'      => isset( $img['url'] ) ? esc_url_raw( (string) $img['url'] ) : '',
				'filename' => isset( $img['filename'] ) ? sanitize_file_name( (string) $img['filename'] ) : 'cover.jpg',
				'alt'      => isset( $img['alt'] ) ? sanitize_text_field( (string) $img['alt'] ) : '',
				'title'    => isset( $img['title'] ) ? sanitize_text_field( (string) $img['title'] ) : '',
				'caption'  => isset( $img['caption'] ) ? sanitize_text_field( (string) $img['caption'] ) : '',
			);
			if ( '' === $out['featured_image']['alt'] ) {
				$warnings[] = 'تصویر شاخص بدون alt ارسال شد (برای سئو و دسترس‌پذیری بد است).';
			}
		}

		// ── سئو ──
		$seo = isset( $d['seo'] ) && is_array( $d['seo'] ) ? $d['seo'] : array();
		$extra = isset( $seo['extra_keywords'] ) && is_array( $seo['extra_keywords'] ) ? $seo['extra_keywords'] : array();
		if ( count( $extra ) > 10 ) {
			$warnings[] = 'کلمات کلیدی اضافی به ۱۰ مورد محدود شد.';
			$extra      = array_slice( $extra, 0, 10 );
		}
		$out['seo'] = array(
			'title'          => isset( $seo['title'] ) ? sanitize_text_field( (string) $seo['title'] ) : '',
			'description'    => isset( $seo['description'] ) ? sanitize_textarea_field( (string) $seo['description'] ) : '',
			'focus_keyword'  => isset( $seo['focus_keyword'] ) ? sanitize_text_field( (string) $seo['focus_keyword'] ) : '',
			'extra_keywords' => array_values( array_filter( array_map( 'sanitize_text_field', $extra ) ) ),
			'canonical'      => isset( $seo['canonical'] ) ? esc_url_raw( (string) $seo['canonical'] ) : '',
			'noindex'        => ! empty( $seo['noindex'] ),
			'og_title'       => isset( $seo['og_title'] ) ? sanitize_text_field( (string) $seo['og_title'] ) : '',
			'og_description' => isset( $seo['og_description'] ) ? sanitize_textarea_field( (string) $seo['og_description'] ) : '',
			'og_image'       => isset( $seo['og_image'] ) ? esc_url_raw( (string) $seo['og_image'] ) : '',
		);

		// ── FAQ ──
		$faq = array();
		if ( ! empty( $d['faq'] ) && is_array( $d['faq'] ) ) {
			foreach ( array_slice( $d['faq'], 0, 10 ) as $item ) {
				$q = isset( $item['question'] ) ? sanitize_text_field( (string) $item['question'] ) : '';
				$a = isset( $item['answer'] ) ? wp_kses_post( (string) $item['answer'] ) : '';
				if ( '' !== $q && '' !== trim( wp_strip_all_tags( $a ) ) ) {
					$faq[] = array(
						'question' => $q,
						'answer'   => $a,
					);
				}
			}
		}
		$out['faq'] = $faq;

		// ── متای دلخواه ──
		$out['meta'] = array();
		if ( ! empty( $d['meta'] ) && is_array( $d['meta'] ) ) {
			foreach ( $d['meta'] as $k => $v ) {
				$key = sanitize_key( (string) $k );
				if ( '' !== $key && ! is_array( $v ) ) {
					$out['meta'][ $key ] = sanitize_text_field( (string) $v );
				}
			}
		}

		$out['lang'] = isset( $d['lang'] ) ? sanitize_key( (string) $d['lang'] ) : '';

		return array(
			'ok'       => empty( $errors ),
			'errors'   => $errors,
			'warnings' => $warnings,
			'data'     => $out,
		);
	}
}
