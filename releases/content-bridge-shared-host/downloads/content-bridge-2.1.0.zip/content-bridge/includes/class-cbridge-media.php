<?php
/**
 * تصویر شاخص — از base64 یا URL.
 *
 * @package Content_Bridge
 */

defined( 'ABSPATH' ) || exit;

/** آپلود و اتصال تصویر شاخص. */
class CBridge_Media {

	/**
	 * نوع تصویر را از magic bytes تشخیص بده.
	 *
	 * عمداً به پسوند فایل یا Content-Type اعتماد نمی‌کنیم — هر دو را
	 * فرستنده کنترل می‌کند. یک فایل PHP با نام .jpg اینجا رد می‌شود.
	 *
	 * @param string $bytes محتوای خام.
	 * @return string|false jpg|png|webp یا false.
	 */
	public static function sniff( $bytes ) {
		if ( ! is_string( $bytes ) || strlen( $bytes ) < 12 ) {
			return false;
		}
		if ( "\xFF\xD8\xFF" === substr( $bytes, 0, 3 ) ) {
			return 'jpg';
		}
		if ( "\x89PNG" === substr( $bytes, 0, 4 ) ) {
			return 'png';
		}
		if ( 'RIFF' === substr( $bytes, 0, 4 ) && 'WEBP' === substr( $bytes, 8, 4 ) ) {
			return 'webp';
		}
		return false;
	}

	/**
	 * تصویر را بساز و به پست وصل کن.
	 *
	 * @param array $img     دیتای تصویر (base64 یا url).
	 * @param int   $post_id شناسه‌ی پست.
	 * @return array{id:int,warnings:array}
	 */
	public static function attach( $img, $post_id ) {
		$warnings = array();

		require_once ABSPATH . 'wp-admin/includes/file.php';
		require_once ABSPATH . 'wp-admin/includes/media.php';
		require_once ABSPATH . 'wp-admin/includes/image.php';

		$attach_id = 0;

		if ( ! empty( $img['base64'] ) ) {
			$bytes = base64_decode( $img['base64'], true ); // phpcs:ignore
			if ( false === $bytes || '' === $bytes ) {
				return array(
					'id'       => 0,
					'warnings' => array( 'داده‌ی base64 تصویر نامعتبر بود.' ),
				);
			}

			$kind = self::sniff( $bytes );
			if ( ! $kind ) {
				return array(
					'id'       => 0,
					'warnings' => array( 'فرمت تصویر شاخص باید JPEG، PNG یا WebP باشد (SVG پذیرفته نمی‌شود).' ),
				);
			}

			// نام فایل تولید می‌شود؛ ورودی فرستنده فقط برای پایه‌ی نام.
			$base     = pathinfo( $img['filename'], PATHINFO_FILENAME );
			$base     = $base ? sanitize_file_name( $base ) : 'cover';
			$filename = $base . '-' . wp_generate_password( 6, false, false ) . '.' . ( 'jpg' === $kind ? 'jpg' : $kind );

			$upload = wp_upload_bits( $filename, null, $bytes );
			if ( ! empty( $upload['error'] ) ) {
				return array(
					'id'       => 0,
					'warnings' => array( 'آپلود تصویر ناموفق: ' . $upload['error'] ),
				);
			}

			$filetype  = wp_check_filetype( $upload['file'], null );
			$attach_id = wp_insert_attachment(
				array(
					'post_mime_type' => $filetype['type'],
					'post_title'     => $img['title'] ? $img['title'] : $base,
					'post_excerpt'   => $img['caption'],
					'post_content'   => '',
					'post_status'    => 'inherit',
				),
				$upload['file'],
				$post_id
			);

			if ( is_wp_error( $attach_id ) || ! $attach_id ) {
				return array(
					'id'       => 0,
					'warnings' => array( 'ثبت پیوست ناموفق بود.' ),
				);
			}

			wp_update_attachment_metadata( $attach_id, wp_generate_attachment_metadata( $attach_id, $upload['file'] ) );

		} elseif ( ! empty( $img['url'] ) ) {
			$attach_id = media_sideload_image( $img['url'], $post_id, $img['title'], 'id' );
			if ( is_wp_error( $attach_id ) ) {
				return array(
					'id'       => 0,
					'warnings' => array( 'دریافت تصویر از URL ناموفق: ' . $attach_id->get_error_message() ),
				);
			}
		} else {
			return array(
				'id'       => 0,
				'warnings' => array(),
			);
		}

		if ( ! empty( $img['alt'] ) ) {
			update_post_meta( $attach_id, '_wp_attachment_image_alt', $img['alt'] );
		}

		set_post_thumbnail( $post_id, $attach_id );

		// یادآوری برای کاور: اگر این تصویر og:image شود، WebP در کارت
		// پیش‌نمایش لینکدین/تلگرام نمایش داده نمی‌شود. JPEG امن است.
		$mime = get_post_mime_type( $attach_id );
		if ( 'image/webp' === $mime ) {
			$warnings[] = 'تصویر WebP است؛ کارت پیش‌نمایش لینکدین و تلگرام WebP را نشان نمی‌دهند. JPEG توصیه می‌شود.';
		}

		return array(
			'id'       => (int) $attach_id,
			'warnings' => $warnings,
		);
	}
}
