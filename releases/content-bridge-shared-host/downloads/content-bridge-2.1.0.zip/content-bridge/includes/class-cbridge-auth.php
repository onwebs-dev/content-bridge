<?php
/**
 * احراز هویت توکن.
 *
 * @package Content_Bridge
 */

defined( 'ABSPATH' ) || exit;

/** توکن، سقف نرخ و تشخیص هدر. */
class CBridge_Auth {

	const OPT_HASH = 'cbridge_token_hash';

	/**
	 * تولید توکن تازه. مقدار خام فقط یک‌بار برگردانده می‌شود و
	 * هرگز ذخیره نمی‌شود — فقط هشش در دیتابیس می‌ماند.
	 *
	 * @return string توکن خام.
	 */
	public static function generate() {
		try {
			$raw = bin2hex( random_bytes( 32 ) );
		} catch ( Exception $e ) {
			$raw = wp_generate_password( 64, false, false );
		}
		update_option( self::OPT_HASH, hash( 'sha256', $raw ) );
		update_option( 'cbridge_token_created', gmdate( 'Y-m-d H:i:s' ) );
		return $raw;
	}

	/** حذف توکن — اندپوینت را عملاً خاموش می‌کند. */
	public static function revoke() {
		delete_option( self::OPT_HASH );
		delete_option( 'cbridge_token_created' );
	}

	/**
	 * آیا توکنی تنظیم شده است؟
	 *
	 * @return bool
	 */
	public static function is_configured() {
		$h = get_option( self::OPT_HASH, '' );
		return is_string( $h ) && strlen( $h ) === 64;
	}

	/**
	 * توکن را از هدرها بیرون بکش.
	 *
	 * چند مسیر بررسی می‌شود چون بعضی سرورها (Apache/LiteSpeed روی هاست
	 * اشتراکی) هدر Authorization را حذف می‌کنند. برای همان‌ها هدر جایگزین
	 * X-CB-Token هم پذیرفته می‌شود.
	 *
	 * @return string
	 */
	public static function extract_token() {
		$candidates = array();

		if ( function_exists( 'getallheaders' ) ) {
			$headers = getallheaders();
			if ( is_array( $headers ) ) {
				foreach ( $headers as $k => $v ) {
					$lk = strtolower( $k );
					if ( 'authorization' === $lk || 'x-cb-token' === $lk ) {
						$candidates[] = $v;
					}
				}
			}
		}

		foreach ( array( 'HTTP_AUTHORIZATION', 'REDIRECT_HTTP_AUTHORIZATION', 'HTTP_X_CB_TOKEN' ) as $key ) {
			if ( ! empty( $_SERVER[ $key ] ) ) {
				$candidates[] = sanitize_text_field( wp_unslash( $_SERVER[ $key ] ) );
			}
		}

		foreach ( $candidates as $value ) {
			$value = trim( (string) $value );
			if ( '' === $value ) {
				continue;
			}
			if ( 0 === stripos( $value, 'bearer ' ) ) {
				return trim( substr( $value, 7 ) );
			}
			return $value;
		}
		return '';
	}

	/**
	 * آیا هدر احراز هویت اصلاً به PHP رسیده؟ (برای تشخیص)
	 *
	 * @return bool
	 */
	public static function header_reached() {
		return '' !== self::extract_token();
	}

	/**
	 * اعتبارسنجی توکن ارائه‌شده.
	 *
	 * هر دو طرف SHA-256 می‌شوند تا طول‌ها یکسان باشد و طول واقعی توکن
	 * از راه زمان‌سنجی لو نرود.
	 *
	 * @param string $provided توکن خام.
	 * @return bool
	 */
	public static function verify( $provided ) {
		$stored = get_option( self::OPT_HASH, '' );
		if ( ! $stored || ! is_string( $provided ) || strlen( $provided ) < 32 ) {
			return false;
		}
		return hash_equals( $stored, hash( 'sha256', $provided ) );
	}

	/**
	 * گیت مشترک REST و AJAX.
	 *
	 * قرارداد خروجی:
	 *   true            → مجاز
	 *   'not_configured'→ توکن ست نشده؛ باید ۴۰۴ با بدنه‌ی خالی بدهیم
	 *   'bad_token'     → ۴۰۱
	 *   'rate_limited'  → ۴۲۹
	 *
	 * @return true|string
	 */
	public static function gate() {
		if ( ! self::is_configured() ) {
			return 'not_configured';
		}

		$token = self::extract_token();
		if ( ! self::verify( $token ) ) {
			CBridge_Log::add( 'auth.fail', 401, 'توکن نامعتبر' );
			return 'bad_token';
		}

		$limit = (int) cbridge_opt( 'rate_limit' );
		if ( $limit > 0 && CBridge_Log::count_since( 'post.create', HOUR_IN_SECONDS ) >= $limit ) {
			CBridge_Log::add( 'rate.block', 429, 'سقف نرخ' );
			return 'rate_limited';
		}

		return true;
	}
}
