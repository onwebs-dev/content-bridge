<?php
/**
 * مسیر پشتیبان روی admin-ajax.php.
 *
 * چرا لازم است: بعضی هاست‌ها و افزونه‌های امنیتی کل /wp-json/ را می‌بندند.
 * admin-ajax.php مسیر کاملاً متفاوتی دارد و معمولاً باز می‌ماند. این تنها
 * جایی است که واقعاً می‌شود محدودیت محیطی را دور زد — یک افزونه‌ای که فقط
 * register_rest_route بزند، دقیقاً به همان دیوار می‌خورد.
 *
 * توجه: اینجا nonce معنا ندارد؛ کلاینت session ندارد. احراز هویت **دقیقاً**
 * همان گیت توکن است.
 *
 * @package Content_Bridge
 */

defined( 'ABSPATH' ) || exit;

/** اندپوینت پشتیبان. */
class CBridge_Ajax {

	/** ثبت هوک‌ها. */
	public static function init() {
		if ( 1 !== (int) cbridge_opt( 'enable_ajax' ) ) {
			return;
		}
		add_action( 'wp_ajax_nopriv_cbridge_publish', array( __CLASS__, 'publish' ) );
		add_action( 'wp_ajax_cbridge_publish', array( __CLASS__, 'publish' ) );
		add_action( 'wp_ajax_nopriv_cbridge_ping', array( __CLASS__, 'ping' ) );
		add_action( 'wp_ajax_cbridge_ping', array( __CLASS__, 'ping' ) );
	}

	/**
	 * پاسخ JSON با کد وضعیت.
	 *
	 * @param array $body بدنه.
	 * @param int   $code کد HTTP.
	 */
	private static function respond( $body, $code ) {
		status_header( $code );
		header( 'Content-Type: application/json; charset=utf-8' );
		echo wp_json_encode( $body, JSON_UNESCAPED_UNICODE );
		exit;
	}

	/** ساخت/به‌روزرسانی مطلب. */
	public static function publish() {
		$gate = CBridge_Auth::gate();

		if ( 'not_configured' === $gate ) {
			status_header( 404 );
			exit; // بدنه‌ی خالی — وجود اندپوینت لو نرود
		}
		if ( 'bad_token' === $gate ) {
			self::respond(
				array(
					'ok'   => false,
					'code' => 'bad_token',
				),
				401
			);
		}
		if ( 'rate_limited' === $gate ) {
			header( 'Retry-After: 3600' );
			self::respond(
				array(
					'ok'   => false,
					'code' => 'rate_limited',
				),
				429
			);
		}

		$body = file_get_contents( 'php://input' ); // phpcs:ignore
		if ( strlen( (string) $body ) > CBRIDGE_MAX_BODY ) {
			self::respond(
				array(
					'ok'   => false,
					'code' => 'too_large',
				),
				413
			);
		}

		$data = json_decode( (string) $body, true );
		if ( ! is_array( $data ) ) {
			self::respond(
				array(
					'ok'   => false,
					'code' => 'invalid_json',
				),
				400
			);
		}

		$res = CBridge_Handler::process( $data );
		self::respond( $res['body'], $res['status'] );
	}

	/** تشخیص محیط از مسیر پشتیبان. */
	public static function ping() {
		$authorized = CBridge_Auth::is_configured() && CBridge_Auth::verify( CBridge_Auth::extract_token() );
		if ( ! $authorized ) {
			self::respond(
				array(
					'ok'            => true,
					'plugin'        => 'content-bridge',
					'authenticated' => false,
				),
				200
			);
		}
		self::respond( CBridge_Rest::diagnostics(), 200 );
	}
}
