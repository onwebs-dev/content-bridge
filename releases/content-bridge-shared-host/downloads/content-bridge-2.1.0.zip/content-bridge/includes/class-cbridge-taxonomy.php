<?php
/**
 * دسته و برچسب با نام — نه با آی‌دی عددی.
 *
 * REST هسته فقط آی‌دی می‌پذیرد؛ همین باعث می‌شود کلاینت مجبور شود برای هر
 * سایت نگاشت نام→آی‌دی بسازد. اینجا با نام کار می‌کنیم و اگر ترم نبود
 * ساخته می‌شود (قابل خاموش‌کردن در تنظیمات).
 *
 * @package Content_Bridge
 */

defined( 'ABSPATH' ) || exit;

/** حل ترم‌ها از روی نام. */
class CBridge_Taxonomy {

	/**
	 * فهرست نام‌ها را به آی‌دی تبدیل کن.
	 *
	 * @param array  $names    نام‌ها.
	 * @param string $taxonomy category یا post_tag.
	 * @return array{ids:array<int>,created:array<string>,warnings:array<string>}
	 */
	public static function resolve( $names, $taxonomy ) {
		$ids      = array();
		$created  = array();
		$warnings = array();
		$may_make = (int) cbridge_opt( 'create_terms' ) === 1;

		foreach ( (array) $names as $name ) {
			$name = trim( (string) $name );
			if ( '' === $name ) {
				continue;
			}

			// جست‌وجو بدون حساسیت به حروف بزرگ/کوچک و با slug هم امتحان می‌کنیم.
			$term = get_term_by( 'name', $name, $taxonomy );
			if ( ! $term ) {
				$term = get_term_by( 'slug', sanitize_title( $name ), $taxonomy );
			}

			if ( $term && ! is_wp_error( $term ) ) {
				$ids[] = (int) $term->term_id;
				continue;
			}

			if ( ! $may_make ) {
				$warnings[] = sprintf( 'ترم «%s» وجود نداشت و ساخت خودکار خاموش است.', $name );
				continue;
			}

			$new = wp_insert_term( $name, $taxonomy );
			if ( is_wp_error( $new ) ) {
				// حالت رقابتی: ممکن است هم‌زمان ساخته شده باشد.
				$existing = $new->get_error_data( 'term_exists' );
				if ( $existing ) {
					$ids[] = (int) $existing;
					continue;
				}
				$warnings[] = sprintf( 'ساخت ترم «%s» ناموفق: %s', $name, $new->get_error_message() );
				continue;
			}

			$ids[]     = (int) $new['term_id'];
			$created[] = $name;
		}

		return array(
			'ids'      => array_values( array_unique( $ids ) ),
			'created'  => $created,
			'warnings' => $warnings,
		);
	}
}
