<?php
/**
 * آداپتور افزونه‌های سئو — قلب Content Bridge.
 *
 * REST هسته‌ی وردپرس هیچ‌کدام از این فیلدها را نمی‌نویسد؛ همین بخش است که
 * «کلمه‌ی کلیدی و توضیحات متا خالی می‌ماند» را حل می‌کند.
 *
 * ⚠️ کلیدهای متا بین نسخه‌های افزونه‌ها تغییر می‌کنند. به همین دلیل بعد از
 * نوشتن، مقدار دوباره خوانده و مقایسه می‌شود (verify write-back) و نتیجه در
 * پاسخ برمی‌گردد — تا «نوشته نشد» هرگز خاموش نماند.
 *
 * @package Content_Bridge
 */

defined( 'ABSPATH' ) || exit;

/** نوشتن فیلدهای سئو در افزونه‌ی فعال. */
class CBridge_Seo {

	/**
	 * افزونه‌ی سئوی فعال را تشخیص بده.
	 *
	 * @return string yoast|rankmath|seopress|aioseo|none
	 */
	public static function detect() {
		$override = (string) cbridge_opt( 'seo_override' );
		if ( $override && 'auto' !== $override ) {
			return $override;
		}
		if ( defined( 'WPSEO_VERSION' ) || class_exists( 'WPSEO_Options' ) ) {
			return 'yoast';
		}
		if ( class_exists( 'RankMath' ) || defined( 'RANK_MATH_VERSION' ) ) {
			return 'rankmath';
		}
		if ( defined( 'SEOPRESS_VERSION' ) ) {
			return 'seopress';
		}
		if ( defined( 'AIOSEO_VERSION' ) || function_exists( 'aioseo' ) ) {
			return 'aioseo';
		}
		return 'none';
	}

	/**
	 * نام نمایشی افزونه.
	 *
	 * @param string $slug شناسه.
	 * @return string
	 */
	public static function label( $slug ) {
		$map = array(
			'yoast'    => 'Yoast SEO',
			'rankmath' => 'Rank Math',
			'seopress' => 'SEOPress',
			'aioseo'   => 'All in One SEO',
			'none'     => 'هیچ افزونه‌ی سئویی فعال نیست',
		);
		return $map[ $slug ] ?? $slug;
	}

	/**
	 * فیلدهای سئو را بنویس و نتیجه‌ی واقعی هر فیلد را برگردان.
	 *
	 * @param int   $post_id شناسه‌ی پست.
	 * @param array $seo     دیتای سئو (نرمال‌شده).
	 * @return array{plugin:string,written:array,warnings:array}
	 */
	public static function write( $post_id, $seo ) {
		$plugin   = self::detect();
		$warnings = array();

		// همیشه یک نسخه‌ی خنثی هم نگه می‌داریم: اگر بعداً افزونه‌ی سئو عوض
		// شد، داده از دست نمی‌رود و قابل مهاجرت است.
		self::write_neutral( $post_id, $seo );

		switch ( $plugin ) {
			case 'yoast':
				$written = self::write_yoast( $post_id, $seo );
				break;
			case 'rankmath':
				$written = self::write_rankmath( $post_id, $seo );
				break;
			case 'seopress':
				$written = self::write_seopress( $post_id, $seo );
				break;
			case 'aioseo':
				$written = self::write_aioseo( $post_id, $seo, $warnings );
				break;
			default:
				$written = array(
					'title'          => false,
					'description'    => false,
					'focus_keyword'  => false,
					'extra_keywords' => false,
				);
				if ( '' !== $seo['title'] || '' !== $seo['focus_keyword'] ) {
					$warnings[] = 'هیچ افزونه‌ی سئویی فعال نیست؛ مقادیر در متاهای _cbridge_seo_* ذخیره شد.';
				}
		}

		foreach ( $written as $field => $ok ) {
			if ( false === $ok && ! empty( $seo[ $field ] ) ) {
				$warnings[] = sprintf( 'فیلد سئوی «%s» نوشته نشد — نسخه‌ی افزونه را بررسی کنید.', $field );
			}
		}

		return array(
			'plugin'   => $plugin,
			'written'  => $written,
			'warnings' => $warnings,
		);
	}

	/**
	 * ذخیره‌ی خنثی — مستقل از هر افزونه.
	 *
	 * @param int   $post_id شناسه.
	 * @param array $seo     دیتا.
	 */
	private static function write_neutral( $post_id, $seo ) {
		$map = array(
			'_cbridge_seo_title'      => $seo['title'],
			'_cbridge_seo_desc'       => $seo['description'],
			'_cbridge_focus_keyword'  => $seo['focus_keyword'],
			'_cbridge_extra_keywords' => implode( ', ', (array) $seo['extra_keywords'] ),
		);
		foreach ( $map as $key => $value ) {
			if ( '' !== $value ) {
				update_post_meta( $post_id, $key, $value );
			}
		}
	}

	/**
	 * کمکی: بنویس و بازخوانی کن.
	 *
	 * @param int    $post_id شناسه.
	 * @param string $key     کلید متا.
	 * @param string $value   مقدار.
	 * @return bool آیا واقعاً نوشته شد.
	 */
	private static function put( $post_id, $key, $value ) {
		if ( '' === $value ) {
			return true; // چیزی برای نوشتن نبود
		}
		update_post_meta( $post_id, $key, $value );
		return (string) get_post_meta( $post_id, $key, true ) === (string) $value;
	}

	/**
	 * Yoast SEO — همه در postmeta.
	 *
	 * @param int   $post_id شناسه.
	 * @param array $seo     دیتا.
	 * @return array<string,bool>
	 */
	private static function write_yoast( $post_id, $seo ) {
		$res = array();
		$res['title']         = self::put( $post_id, '_yoast_wpseo_title', $seo['title'] );
		$res['description']   = self::put( $post_id, '_yoast_wpseo_metadesc', $seo['description'] );
		$res['focus_keyword'] = self::put( $post_id, '_yoast_wpseo_focuskw', $seo['focus_keyword'] );

		// کلمات کلیدی اضافی فقط در نسخه‌ی Premium خوانده می‌شوند، ولی نوشتنش
		// بی‌ضرر است و اگر بعداً Premium نصب شد، آماده است.
		$res['extra_keywords'] = true;
		if ( ! empty( $seo['extra_keywords'] ) ) {
			$payload = array();
			foreach ( $seo['extra_keywords'] as $kw ) {
				$payload[] = array(
					'keyword' => $kw,
					'score'   => '',
					'slug'    => '',
				);
			}
			$json                  = wp_json_encode( $payload );
			$res['extra_keywords'] = self::put( $post_id, '_yoast_wpseo_focuskeywords', $json );
		}

		if ( $seo['canonical'] ) {
			self::put( $post_id, '_yoast_wpseo_canonical', $seo['canonical'] );
		}
		if ( $seo['noindex'] ) {
			update_post_meta( $post_id, '_yoast_wpseo_meta-robots-noindex', '1' );
		}
		if ( $seo['og_title'] ) {
			self::put( $post_id, '_yoast_wpseo_opengraph-title', $seo['og_title'] );
		}
		if ( $seo['og_description'] ) {
			self::put( $post_id, '_yoast_wpseo_opengraph-description', $seo['og_description'] );
		}
		if ( $seo['og_image'] ) {
			self::put( $post_id, '_yoast_wpseo_opengraph-image', $seo['og_image'] );
		}

		return $res;
	}

	/**
	 * Rank Math — کلمات کلیدی همه در یک فیلد، جداشده با ویرگول، اولی اصلی.
	 *
	 * @param int   $post_id شناسه.
	 * @param array $seo     دیتا.
	 * @return array<string,bool>
	 */
	private static function write_rankmath( $post_id, $seo ) {
		$res = array();
		$res['title']       = self::put( $post_id, 'rank_math_title', $seo['title'] );
		$res['description'] = self::put( $post_id, 'rank_math_description', $seo['description'] );

		$keywords = array();
		if ( $seo['focus_keyword'] ) {
			$keywords[] = $seo['focus_keyword'];
		}
		$keywords = array_merge( $keywords, (array) $seo['extra_keywords'] );
		$joined   = implode( ',', array_filter( $keywords ) );

		$ok                    = self::put( $post_id, 'rank_math_focus_keyword', $joined );
		$res['focus_keyword']  = $ok;
		$res['extra_keywords'] = $ok;

		if ( $seo['canonical'] ) {
			self::put( $post_id, 'rank_math_canonical_url', $seo['canonical'] );
		}
		if ( $seo['noindex'] ) {
			update_post_meta( $post_id, 'rank_math_robots', array( 'noindex' ) );
		}
		if ( $seo['og_title'] ) {
			self::put( $post_id, 'rank_math_facebook_title', $seo['og_title'] );
		}
		if ( $seo['og_description'] ) {
			self::put( $post_id, 'rank_math_facebook_description', $seo['og_description'] );
		}
		if ( $seo['og_image'] ) {
			self::put( $post_id, 'rank_math_facebook_image', $seo['og_image'] );
		}

		return $res;
	}

	/**
	 * SEOPress.
	 *
	 * @param int   $post_id شناسه.
	 * @param array $seo     دیتا.
	 * @return array<string,bool>
	 */
	private static function write_seopress( $post_id, $seo ) {
		$res = array();
		$res['title']         = self::put( $post_id, '_seopress_titles_title', $seo['title'] );
		$res['description']   = self::put( $post_id, '_seopress_titles_desc', $seo['description'] );
		$res['focus_keyword'] = self::put( $post_id, '_seopress_analysis_target_kw', $seo['focus_keyword'] );

		$res['extra_keywords'] = true;
		if ( ! empty( $seo['extra_keywords'] ) ) {
			$all = array_merge( array( $seo['focus_keyword'] ), (array) $seo['extra_keywords'] );
			$res['extra_keywords'] = self::put(
				$post_id,
				'_seopress_analysis_target_kw',
				implode( ',', array_filter( $all ) )
			);
		}

		if ( $seo['canonical'] ) {
			self::put( $post_id, '_seopress_robots_canonical', $seo['canonical'] );
		}
		if ( $seo['noindex'] ) {
			update_post_meta( $post_id, '_seopress_robots_index', 'yes' );
		}
		if ( $seo['og_title'] ) {
			self::put( $post_id, '_seopress_social_fb_title', $seo['og_title'] );
		}
		if ( $seo['og_image'] ) {
			self::put( $post_id, '_seopress_social_fb_img', $seo['og_image'] );
		}

		return $res;
	}

	/**
	 * All in One SEO v4 — داده در جدول اختصاصی است، نه postmeta.
	 * پس فقط از مدل خودشان استفاده می‌کنیم و هرگز مستقیم در جدول نمی‌نویسیم.
	 *
	 * @param int   $post_id  شناسه.
	 * @param array $seo      دیتا.
	 * @param array $warnings ارجاع هشدارها.
	 * @return array<string,bool>
	 */
	private static function write_aioseo( $post_id, $seo, &$warnings ) {
		$res = array(
			'title'          => false,
			'description'    => false,
			'focus_keyword'  => false,
			'extra_keywords' => false,
		);

		if ( ! class_exists( '\AIOSEO\Plugin\Common\Models\Post' ) ) {
			$warnings[] = 'AIOSEO فعال است ولی مدل داده‌اش در دسترس نیست؛ نسخه را بررسی کنید.';
			return $res;
		}

		try {
			$model = \AIOSEO\Plugin\Common\Models\Post::getPost( $post_id );
			if ( ! $model ) {
				$warnings[] = 'AIOSEO رکورد پست را برنگرداند.';
				return $res;
			}

			if ( '' !== $seo['title'] ) {
				$model->title    = $seo['title'];
				$res['title']    = true;
			}
			if ( '' !== $seo['description'] ) {
				$model->description  = $seo['description'];
				$res['description']  = true;
			}
			if ( '' !== $seo['focus_keyword'] ) {
				$additional = array();
				foreach ( (array) $seo['extra_keywords'] as $kw ) {
					$additional[] = array( 'keyphrase' => $kw );
				}
				$model->keyphrases = wp_json_encode(
					array(
						'focus'      => array( 'keyphrase' => $seo['focus_keyword'] ),
						'additional' => $additional,
					)
				);
				$res['focus_keyword']  = true;
				$res['extra_keywords'] = true;
			}
			if ( $seo['canonical'] ) {
				$model->canonical_url = $seo['canonical'];
			}
			if ( $seo['og_title'] ) {
				$model->og_title = $seo['og_title'];
			}
			if ( $seo['og_description'] ) {
				$model->og_description = $seo['og_description'];
			}

			$model->save();
		} catch ( Throwable $e ) {
			$warnings[] = 'نوشتن در AIOSEO ناموفق: ' . $e->getMessage();
		}

		return $res;
	}
}
