<?php
/**
 * FAQ — رندر باز در انتهای مطلب + اسکیمای FAQPage.
 *
 * دو قاعده که از تجربه آمده‌اند:
 *  ۱. FAQ باید **باز** رندر شود (dl/dt/dd)، نه داخل <details>. متن پنهان
 *     برای استخراج‌کننده‌های موتور جستجو ارزش کمتری دارد.
 *  ۲. اسکیمای FAQPage خالی هرگز صادر نشود — در Rich Results اخطار می‌دهد.
 *
 * @package Content_Bridge
 */

defined( 'ABSPATH' ) || exit;

/** ذخیره و نمایش FAQ. */
class CBridge_Faq {

	const META = '_cbridge_faq';

	/** ثبت هوک‌های نمایش. */
	public static function init() {
		$mode = (string) cbridge_opt( 'faq_output' );
		if ( 'off' === $mode ) {
			return;
		}
		if ( 'append' === $mode ) {
			add_filter( 'the_content', array( __CLASS__, 'append_html' ), 20 );
		}
		add_action( 'wp_head', array( __CLASS__, 'print_schema' ), 20 );
	}

	/**
	 * ذخیره‌ی آیتم‌ها روی پست.
	 *
	 * @param int   $post_id شناسه.
	 * @param array $items   آیتم‌ها.
	 */
	public static function save( $post_id, $items ) {
		if ( empty( $items ) ) {
			delete_post_meta( $post_id, self::META );
			return;
		}
		update_post_meta( $post_id, self::META, wp_json_encode( array_values( $items ) ) );
	}

	/**
	 * خواندن آیتم‌ها.
	 *
	 * @param int $post_id شناسه.
	 * @return array
	 */
	public static function get( $post_id ) {
		$raw = get_post_meta( $post_id, self::META, true );
		if ( ! $raw ) {
			return array();
		}
		$data = json_decode( $raw, true );
		return is_array( $data ) ? $data : array();
	}

	/**
	 * افزودن بلوک FAQ به انتهای محتوا.
	 *
	 * @param string $content محتوای پست.
	 * @return string
	 */
	public static function append_html( $content ) {
		if ( ! is_singular() || ! in_the_loop() || ! is_main_query() ) {
			return $content;
		}
		$items = self::get( get_the_ID() );
		if ( empty( $items ) ) {
			return $content;
		}

		$out  = '<section class="cbridge-faq">';
		$out .= '<h2>' . esc_html__( 'سؤالات پرتکرار', 'content-bridge' ) . '</h2><dl>';
		foreach ( $items as $item ) {
			$q = isset( $item['question'] ) ? $item['question'] : '';
			$a = isset( $item['answer'] ) ? $item['answer'] : '';
			if ( '' === $q || '' === $a ) {
				continue;
			}
			$out .= '<dt>' . esc_html( $q ) . '</dt>';
			$out .= '<dd>' . wp_kses_post( $a ) . '</dd>';
		}
		$out .= '</dl></section>';

		return $content . $out;
	}

	/** خروجی JSON-LD در head. */
	public static function print_schema() {
		if ( ! is_singular() ) {
			return;
		}
		$items = self::get( get_queried_object_id() );
		if ( empty( $items ) ) {
			return; // اسکیمای خالی هرگز
		}

		$entities = array();
		foreach ( $items as $item ) {
			$q = isset( $item['question'] ) ? wp_strip_all_tags( $item['question'] ) : '';
			$a = isset( $item['answer'] ) ? wp_strip_all_tags( $item['answer'] ) : '';
			if ( '' === $q || '' === $a ) {
				continue;
			}
			$entities[] = array(
				'@type'          => 'Question',
				'name'           => $q,
				'acceptedAnswer' => array(
					'@type' => 'Answer',
					'text'  => $a,
				),
			);
		}
		if ( empty( $entities ) ) {
			return;
		}

		$schema = array(
			'@context'   => 'https://schema.org',
			'@type'      => 'FAQPage',
			'mainEntity' => $entities,
		);

		echo "\n<!-- Content Bridge FAQ -->\n";
		echo '<script type="application/ld+json">' . wp_json_encode( $schema, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES ) . "</script>\n";
	}
}
