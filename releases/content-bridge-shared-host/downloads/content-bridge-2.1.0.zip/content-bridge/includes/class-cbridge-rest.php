<?php
/**
 * مسیرهای REST.
 *
 * @package Content_Bridge
 */

defined( 'ABSPATH' ) || exit;

/** ثبت روت‌های /wp-json/cbridge/v1/*. */
class CBridge_Rest {

	/** ثبت هوک. */
	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register' ) );
	}

	/** ثبت مسیرها. */
	public static function register() {
		register_rest_route(
			CBRIDGE_NS,
			'/posts',
			array(
				array(
					'methods'             => 'POST',
					'callback'            => array( __CLASS__, 'create' ),
					// هرگز __return_true — این گیت واقعی است.
					'permission_callback' => array( __CLASS__, 'permission' ),
				),
				array(
					'methods'             => 'GET',
					'callback'            => array( __CLASS__, 'listing' ),
					'permission_callback' => array( __CLASS__, 'permission' ),
				),
			)
		);

		register_rest_route(
			CBRIDGE_NS,
			'/ping',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'ping' ),
				'permission_callback' => '__return_true', // پاسخ بدون توکن حداقلی است
			)
		);
	}

	/**
	 * گیت دسترسی.
	 *
	 * @return true|WP_Error
	 */
	public static function permission() {
		$gate = CBridge_Auth::gate();
		if ( true === $gate ) {
			return true;
		}

		if ( 'not_configured' === $gate ) {
			// عمداً ۴۰۴: تا توکن ست نشود، وجودِ اندپوینت هم لو نرود.
			return new WP_Error( 'rest_no_route', '', array( 'status' => 404 ) );
		}
		if ( 'rate_limited' === $gate ) {
			return new WP_Error(
				'rate_limited',
				__( 'سقف نرخ درخواست پر شده است.', 'content-bridge' ),
				array( 'status' => 429 )
			);
		}
		return new WP_Error(
			'bad_token',
			__( 'توکن نامعتبر است.', 'content-bridge' ),
			array( 'status' => 401 )
		);
	}

	/**
	 * ساخت/به‌روزرسانی مطلب.
	 *
	 * @param WP_REST_Request $req درخواست.
	 * @return WP_REST_Response
	 */
	public static function create( WP_REST_Request $req ) {
		$body = $req->get_body();

		// سقف حجم دستی — محدودیت‌های آپلود به بدنه‌ی JSON اعمال نمی‌شود.
		if ( strlen( (string) $body ) > CBRIDGE_MAX_BODY ) {
			return new WP_REST_Response(
				array(
					'ok'    => false,
					'code'  => 'too_large',
					'error' => 'حجم بدنه بیش از ۸ مگابایت است.',
				),
				413
			);
		}

		$data = json_decode( $body, true );
		if ( ! is_array( $data ) ) {
			$data = $req->get_json_params();
		}
		if ( ! is_array( $data ) ) {
			return new WP_REST_Response(
				array(
					'ok'    => false,
					'code'  => 'invalid_json',
					'error' => 'بدنه JSON معتبر نیست.',
				),
				400
			);
		}

		$res = CBridge_Handler::process( $data );
		return new WP_REST_Response( $res['body'], $res['status'] );
	}

	/**
	 * فهرست سبک.
	 *
	 * @param WP_REST_Request $req درخواست.
	 * @return WP_REST_Response
	 */
	public static function listing( WP_REST_Request $req ) {
		$limit = (int) $req->get_param( 'limit' );
		$ptype = sanitize_key( (string) $req->get_param( 'post_type' ) );
		$posts = CBridge_Handler::listing( $limit ? $limit : 50, $ptype );

		return new WP_REST_Response(
			array(
				'ok'    => true,
				'count' => count( $posts ),
				'posts' => $posts,
			),
			200
		);
	}

	/**
	 * تشخیص محیط.
	 *
	 * بدون توکن فقط یک ok برمی‌گرداند؛ با توکن معتبر گزارش کامل.
	 *
	 * @param WP_REST_Request $req درخواست.
	 * @return WP_REST_Response
	 */
	public static function ping( WP_REST_Request $req ) { // phpcs:ignore VariableAnalysis.CodeAnalysis.VariableAnalysis.UnusedVariable
		$authorized = CBridge_Auth::is_configured() && CBridge_Auth::verify( CBridge_Auth::extract_token() );

		if ( ! $authorized ) {
			return new WP_REST_Response(
				array(
					'ok'             => true,
					'plugin'         => 'content-bridge',
					'authenticated'  => false,
				),
				200
			);
		}

		return new WP_REST_Response( self::diagnostics(), 200 );
	}

	/**
	 * گزارش وضعیت محیط — همان چیزی که صفحه‌ی «تشخیص» نشان می‌دهد.
	 *
	 * @return array
	 */
	public static function diagnostics() {
		$uploads = wp_upload_dir();

		return array(
			'ok'                   => true,
			'authenticated'        => true,
			'plugin_version'       => CBRIDGE_VERSION,
			'wp'                   => get_bloginfo( 'version' ),
			'php'                  => PHP_VERSION,
			// مهم‌ترین فیلد: اگر false باشد، سرور هدر Authorization را حذف کرده.
			'auth_header_received' => CBridge_Auth::header_reached(),
			'rest_enabled'         => true,
			'ajax_fallback'        => 1 === (int) cbridge_opt( 'enable_ajax' ),
			'https'                => is_ssl(),
			'seo_plugin'           => CBridge_Seo::detect(),
			'seo_plugin_label'     => CBridge_Seo::label( CBridge_Seo::detect() ),
			'can_create_terms'     => 1 === (int) cbridge_opt( 'create_terms' ),
			'uploads_writable'     => empty( $uploads['error'] ) && wp_is_writable( $uploads['basedir'] ),
			'allow_publish'        => 1 === (int) cbridge_opt( 'allow_publish' ),
			'post_types'           => (array) cbridge_opt( 'post_types' ),
			'rate_limit'           => (int) cbridge_opt( 'rate_limit' ),
			'posts_last_hour'      => CBridge_Log::count_since( 'post.create', HOUR_IN_SECONDS ),
		);
	}
}
