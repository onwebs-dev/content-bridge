<?php
/**
 * حذف کامل — فقط وقتی کاربر افزونه را «حذف» می‌کند، نه غیرفعال.
 *
 * @package Content_Bridge
 */

defined( 'WP_UNINSTALL_PLUGIN' ) || exit;

global $wpdb;

// گزینه‌ها
delete_option( 'cbridge_settings' );
delete_option( 'cbridge_token_hash' );
delete_option( 'cbridge_token_created' );
delete_option( 'cbridge_db_version' );
delete_transient( 'cbridge_new_token' );

// متاهای پست
$meta_keys = array(
	'_cbridge_external_id',
	'_cbridge_faq',
	'_cbridge_seo_title',
	'_cbridge_seo_desc',
	'_cbridge_focus_keyword',
	'_cbridge_extra_keywords',
);
foreach ( $meta_keys as $key ) {
	$wpdb->delete( $wpdb->postmeta, array( 'meta_key' => $key ), array( '%s' ) );
}

// جدول لاگ
$table = $wpdb->prefix . 'cbridge_log';
$wpdb->query( "DROP TABLE IF EXISTS {$table}" ); // phpcs:ignore

// زمان‌بندی
wp_clear_scheduled_hook( 'cbridge_prune_logs' );
