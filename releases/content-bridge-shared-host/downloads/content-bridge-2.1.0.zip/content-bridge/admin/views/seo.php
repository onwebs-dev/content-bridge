<?php
/**
 * تب سئو.
 *
 * @package Content_Bridge
 */

defined( 'ABSPATH' ) || exit;

$cb_detected = CBridge_Seo::detect();
$cb_options  = array(
	'auto'     => __( 'تشخیص خودکار (توصیه‌شده)', 'content-bridge' ),
	'yoast'    => 'Yoast SEO',
	'rankmath' => 'Rank Math',
	'seopress' => 'SEOPress',
	'aioseo'   => 'All in One SEO',
	'none'     => __( 'هیچ‌کدام — فقط متای خنثی', 'content-bridge' ),
);
?>

<h2 class="cbridge-h2"><?php esc_html_e( 'افزونه‌ی سئو', 'content-bridge' ); ?></h2>

<div class="cbridge-card cbridge-detect">
	<div class="cbridge-detect-icon"><span class="dashicons dashicons-search"></span></div>
	<div>
		<strong><?php esc_html_e( 'شناسایی‌شده:', 'content-bridge' ); ?> <?php echo esc_html( CBridge_Seo::label( $cb_detected ) ); ?></strong>
		<p class="cbridge-hint">
			<?php esc_html_e( 'این بخش همان چیزی است که REST هسته‌ی وردپرس نمی‌نویسد: عنوان سئو، توضیحات متا و کلمه‌ی کلیدی. Content Bridge آن‌ها را مستقیم در افزونه‌ی فعال می‌نویسد.', 'content-bridge' ); ?>
		</p>
	</div>
</div>

<form method="post">
	<?php CBridge_Admin::form_fields( 'save_settings' ); ?>
	<input type="hidden" name="cbridge_tab" value="seo">

	<div class="cbridge-card">
		<div class="cbridge-field">
			<label class="cbridge-label" for="cb-seo"><?php esc_html_e( 'مقصد نوشتن فیلدهای سئو', 'content-bridge' ); ?></label>
			<select id="cb-seo" name="cbridge[seo_override]" class="cbridge-input">
				<?php foreach ( $cb_options as $cb_k => $cb_v ) : ?>
					<option value="<?php echo esc_attr( $cb_k ); ?>" <?php selected( (string) cbridge_opt( 'seo_override' ), $cb_k ); ?>>
						<?php echo esc_html( $cb_v ); ?>
					</option>
				<?php endforeach; ?>
			</select>
			<p class="cbridge-hint">
				<?php esc_html_e( 'فقط وقتی دستی انتخاب کنید که تشخیص خودکار اشتباه باشد — مثلاً وقتی دو افزونه‌ی سئو هم‌زمان نصب‌اند.', 'content-bridge' ); ?>
			</p>
		</div>

		<div class="cbridge-field">
			<label class="cbridge-label" for="cb-faq"><?php esc_html_e( 'خروجی بخش سؤالات پرتکرار', 'content-bridge' ); ?></label>
			<select id="cb-faq" name="cbridge[faq_output]" class="cbridge-input">
				<option value="append" <?php selected( (string) cbridge_opt( 'faq_output' ), 'append' ); ?>><?php esc_html_e( 'متن + اسکیما (توصیه‌شده)', 'content-bridge' ); ?></option>
				<option value="schema_only" <?php selected( (string) cbridge_opt( 'faq_output' ), 'schema_only' ); ?>><?php esc_html_e( 'فقط اسکیما', 'content-bridge' ); ?></option>
				<option value="off" <?php selected( (string) cbridge_opt( 'faq_output' ), 'off' ); ?>><?php esc_html_e( 'خاموش', 'content-bridge' ); ?></option>
			</select>
			<p class="cbridge-hint">
				<?php esc_html_e( 'بخش FAQ باز رندر می‌شود، نه داخل آکاردئون — متن پنهان برای استخراج موتورهای جستجو ارزش کمتری دارد. اگر مقاله FAQ نداشته باشد، هیچ اسکیمایی صادر نمی‌شود (اسکیمای خالی در Rich Results اخطار می‌دهد).', 'content-bridge' ); ?>
			</p>
		</div>
	</div>

	<p class="cbridge-submit">
		<button type="submit" class="button button-primary button-hero"><?php esc_html_e( 'ذخیره‌ی تنظیمات', 'content-bridge' ); ?></button>
	</p>
</form>

<h2 class="cbridge-h2"><?php esc_html_e( 'فیلدهایی که نوشته می‌شوند', 'content-bridge' ); ?></h2>

<div class="cbridge-card">
	<table class="cbridge-table">
		<thead>
			<tr>
				<th><?php esc_html_e( 'فیلد ورودی', 'content-bridge' ); ?></th>
				<th><?php esc_html_e( 'کجا نوشته می‌شود', 'content-bridge' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<tr><td><code>seo.title</code></td><td><?php esc_html_e( 'عنوان سئو', 'content-bridge' ); ?></td></tr>
			<tr><td><code>seo.description</code></td><td><?php esc_html_e( 'توضیحات متا', 'content-bridge' ); ?></td></tr>
			<tr><td><code>seo.focus_keyword</code></td><td><?php esc_html_e( 'کلمه‌ی کلیدی اصلی', 'content-bridge' ); ?></td></tr>
			<tr><td><code>seo.extra_keywords</code></td><td><?php esc_html_e( 'کلمات کلیدی اضافی', 'content-bridge' ); ?></td></tr>
			<tr><td><code>seo.canonical</code></td><td>canonical URL</td></tr>
			<tr><td><code>seo.noindex</code></td><td>robots</td></tr>
			<tr><td><code>seo.og_*</code></td><td>Open Graph</td></tr>
		</tbody>
	</table>

	<div class="cbridge-inline-note">
		<strong><?php esc_html_e( 'تأیید نوشتن:', 'content-bridge' ); ?></strong>
		<?php esc_html_e( 'بعد از هر نوشتن، مقدار دوباره خوانده و مقایسه می‌شود و نتیجه در پاسخ API با کلید seo_written برمی‌گردد. اگر فیلدی نوشته نشده باشد، false برمی‌گردد و در warnings هم می‌آید — چون کلیدهای متا بین نسخه‌های افزونه‌ها تغییر می‌کنند و این تنها راهی است که خطا خاموش نماند.', 'content-bridge' ); ?>
	</div>
</div>
