<?php
/**
 * تب راهنما.
 *
 * @package Content_Bridge
 */

defined( 'ABSPATH' ) || exit;

$cb_rest = rest_url( CBRIDGE_NS . '/' );
?>

<h2 class="cbridge-h2"><?php esc_html_e( 'شروع سریع', 'content-bridge' ); ?></h2>

<div class="cbridge-card">
	<ol class="cbridge-steps">
		<li><strong><?php esc_html_e( 'توکن بسازید', 'content-bridge' ); ?></strong> — <?php esc_html_e( 'تب «اتصال و توکن». مقدار فقط یک بار نمایش داده می‌شود.', 'content-bridge' ); ?></li>
		<li><strong><?php esc_html_e( 'تشخیص را اجرا کنید', 'content-bridge' ); ?></strong> — <?php esc_html_e( 'تب «تشخیص»؛ اگر هدر احراز هویت قرمز بود، همان‌جا راه‌حل آمده.', 'content-bridge' ); ?></li>
		<li><strong><?php esc_html_e( 'یک مطلب آزمایشی بفرستید', 'content-bridge' ); ?></strong> — <?php esc_html_e( 'با انتشار مستقیمِ خاموش، تا خروجی را ببینید.', 'content-bridge' ); ?></li>
		<li><strong><?php esc_html_e( 'همان درخواست را دوباره بفرستید', 'content-bridge' ); ?></strong> — <?php esc_html_e( 'باید action=updated و همان id برگردد، نه مطلب دوم.', 'content-bridge' ); ?></li>
		<li><strong><?php esc_html_e( 'انتشار را روشن کنید', 'content-bridge' ); ?></strong> — <?php esc_html_e( 'وقتی از خروجی مطمئن شدید.', 'content-bridge' ); ?></li>
	</ol>
</div>

<h2 class="cbridge-h2"><?php esc_html_e( 'ساختار داده‌ی ورودی', 'content-bridge' ); ?></h2>

<div class="cbridge-card">
	<pre class="cbridge-pre" dir="ltr">POST <?php echo esc_html( $cb_rest . 'posts' ); ?>

{
  "external_id": "2026-08-02-my-article",   // required — idempotency key
  "title":       "...",                     // required
  "content":     "&lt;h2&gt;...&lt;/h2&gt;&lt;p&gt;...&lt;/p&gt;",  // required
  "slug":        "my-article",
  "excerpt":     "...",
  "status":      "publish",                 // publish | draft | future
  "date":        "2026-08-05T09:00:00+03:30",
  "post_type":   "post",

  "author":      { "name": "...", "email": "..." },
  "categories":  ["Web Design"],            // by NAME, created if missing
  "tags":        ["seo", "wordpress"],

  "featured_image": {
    "base64":   "...",                      // or "url"
    "filename": "cover.jpg",
    "alt":      "descriptive alt text"
  },

  "seo": {
    "title":          "...",
    "description":    "...",
    "focus_keyword":  "...",
    "extra_keywords": ["...", "..."],
    "canonical":      "",
    "noindex":        false
  },

  "faq": [ { "question": "...", "answer": "..." } ],
  "meta": {},
  "lang": "fa"
}</pre>
</div>

<h2 class="cbridge-h2"><?php esc_html_e( 'پاسخ موفق', 'content-bridge' ); ?></h2>

<div class="cbridge-card">
	<pre class="cbridge-pre" dir="ltr">201 Created

{
  "ok": true,
  "action": "created",          // یا "updated" در ارسال دوباره
  "id": 1042,
  "external_id": "2026-08-02-my-article",
  "status": "publish",
  "downgraded": false,          // true یعنی پیش‌نویس ماند — مثل خطا رفتار کنید
  "link": "https://...",
  "featured_media": 1043,
  "terms_created": ["Web Design"],
  "content_stripped": false,    // true یعنی HTML حذف شده
  "seo_written": { "plugin": "rankmath", "focus_keyword": true, ... },
  "warnings": []
}</pre>

	<div class="cbridge-inline-note">
		<strong><?php esc_html_e( 'نکته‌ی مهم برای سمت کلاینت:', 'content-bridge' ); ?></strong>
		<?php esc_html_e( 'پرچم‌های downgraded و content_stripped را مثل خطا رفتار کنید. اگر آن‌ها را «موفق» بشمارید، ممکن است پیش‌نویس محلی را حذف کنید در حالی که مطلب هرگز منتشر نشده است.', 'content-bridge' ); ?>
	</div>
</div>

<h2 class="cbridge-h2"><?php esc_html_e( 'کدهای خطا', 'content-bridge' ); ?></h2>

<div class="cbridge-card">
	<table class="cbridge-table">
		<tbody>
			<tr><td><code>404</code></td><td><?php esc_html_e( 'توکن تنظیم نشده — اندپوینت عمداً وجود ندارد.', 'content-bridge' ); ?></td></tr>
			<tr><td><code>401</code></td><td><?php esc_html_e( 'توکن نامعتبر.', 'content-bridge' ); ?></td></tr>
			<tr><td><code>400</code></td><td><?php esc_html_e( 'ورودی نامعتبر — فهرست خطاها در errors برمی‌گردد.', 'content-bridge' ); ?></td></tr>
			<tr><td><code>413</code></td><td><?php esc_html_e( 'بدنه بیش از ۸ مگابایت.', 'content-bridge' ); ?></td></tr>
			<tr><td><code>429</code></td><td><?php esc_html_e( 'سقف نرخ ساعتی.', 'content-bridge' ); ?></td></tr>
			<tr><td><code>500</code></td><td><?php esc_html_e( 'خطای وردپرس هنگام ساخت پست.', 'content-bridge' ); ?></td></tr>
		</tbody>
	</table>
</div>

<div class="cbridge-card cbridge-about">
	<h3><?php esc_html_e( 'درباره', 'content-bridge' ); ?></h3>
	<p>
		<strong>Content Bridge</strong> — <?php esc_html_e( 'نسخه', 'content-bridge' ); ?> <?php echo esc_html( CBRIDGE_VERSION ); ?><br>
		<?php esc_html_e( 'توسعه‌دهنده: امیرحسین مقتدر — شرکت ویرا وب آریا', 'content-bridge' ); ?><br>
		<a href="https://onwebs.ir" target="_blank" rel="noopener">onwebs.ir</a>
	</p>
</div>
