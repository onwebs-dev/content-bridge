<?php
/**
 * تب داشبورد.
 *
 * @package Content_Bridge
 */

defined( 'ABSPATH' ) || exit;

$cb_diag    = CBridge_Rest::diagnostics();
$cb_created = (int) CBridge_Log::count_since( 'post.create', DAY_IN_SECONDS );
$cb_month   = (int) CBridge_Log::count_since( 'post.create', 30 * DAY_IN_SECONDS );
$cb_fails   = (int) CBridge_Log::count_since( 'auth.fail', DAY_IN_SECONDS );
$cb_recent  = CBridge_Log::recent( 8 );
?>

<h2 class="cbridge-h2"><?php esc_html_e( 'وضعیت کلی', 'content-bridge' ); ?></h2>

<div class="cbridge-stats">
	<div class="cbridge-stat">
		<span class="num"><?php echo esc_html( number_format_i18n( $cb_created ) ); ?></span>
		<span class="lbl"><?php esc_html_e( 'مطلب امروز', 'content-bridge' ); ?></span>
	</div>
	<div class="cbridge-stat">
		<span class="num"><?php echo esc_html( number_format_i18n( $cb_month ) ); ?></span>
		<span class="lbl"><?php esc_html_e( 'مطلب ۳۰ روز اخیر', 'content-bridge' ); ?></span>
	</div>
	<div class="cbridge-stat">
		<span class="num"><?php echo esc_html( number_format_i18n( $cb_diag['posts_last_hour'] ) ); ?><small>/<?php echo esc_html( $cb_diag['rate_limit'] ); ?></small></span>
		<span class="lbl"><?php esc_html_e( 'در ساعت گذشته', 'content-bridge' ); ?></span>
	</div>
	<div class="cbridge-stat <?php echo $cb_fails > 0 ? 'is-warn' : ''; ?>">
		<span class="num"><?php echo esc_html( number_format_i18n( $cb_fails ) ); ?></span>
		<span class="lbl"><?php esc_html_e( 'خطای احراز امروز', 'content-bridge' ); ?></span>
	</div>
</div>

<div class="cbridge-grid-2">
	<div class="cbridge-card">
		<h3><?php esc_html_e( 'آمادگی سیستم', 'content-bridge' ); ?></h3>
		<ul class="cbridge-checklist">
			<?php
			$cb_checks = array(
				array( __( 'توکن تنظیم شده', 'content-bridge' ), CBridge_Auth::is_configured() ),
				array( __( 'هدر احراز هویت به PHP می‌رسد', 'content-bridge' ), $cb_diag['auth_header_received'] ),
				array( __( 'اتصال امن (HTTPS)', 'content-bridge' ), $cb_diag['https'] ),
				array( __( 'پوشه‌ی آپلود قابل نوشتن', 'content-bridge' ), $cb_diag['uploads_writable'] ),
				array( __( 'افزونه‌ی سئو شناسایی شد', 'content-bridge' ), 'none' !== $cb_diag['seo_plugin'] ),
				array( __( 'انتشار مستقیم فعال', 'content-bridge' ), $cb_diag['allow_publish'] ),
			);
			foreach ( $cb_checks as $cb_c ) :
				?>
				<li class="<?php echo $cb_c[1] ? 'ok' : 'no'; ?>">
					<span class="dot"></span><?php echo esc_html( $cb_c[0] ); ?>
				</li>
			<?php endforeach; ?>
		</ul>
		<?php if ( ! $cb_diag['auth_header_received'] ) : ?>
			<div class="cbridge-inline-warn">
				<?php esc_html_e( 'هدر Authorization به PHP نمی‌رسد. تب «تشخیص» راه‌حل را نشان می‌دهد.', 'content-bridge' ); ?>
			</div>
		<?php endif; ?>
	</div>

	<div class="cbridge-card">
		<h3><?php esc_html_e( 'پیکربندی فعلی', 'content-bridge' ); ?></h3>
		<table class="cbridge-kv">
			<tr>
				<th><?php esc_html_e( 'افزونه‌ی سئو', 'content-bridge' ); ?></th>
				<td><?php echo esc_html( $cb_diag['seo_plugin_label'] ); ?></td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'نوع پست مجاز', 'content-bridge' ); ?></th>
				<td><code><?php echo esc_html( implode( ', ', $cb_diag['post_types'] ) ); ?></code></td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'سقف نرخ', 'content-bridge' ); ?></th>
				<td><?php echo esc_html( $cb_diag['rate_limit'] ); ?> <?php esc_html_e( 'در ساعت', 'content-bridge' ); ?></td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'مسیر پشتیبان', 'content-bridge' ); ?></th>
				<td><?php echo $cb_diag['ajax_fallback'] ? esc_html__( 'فعال', 'content-bridge' ) : esc_html__( 'خاموش', 'content-bridge' ); ?></td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'وردپرس / PHP', 'content-bridge' ); ?></th>
				<td><?php echo esc_html( $cb_diag['wp'] . ' / ' . $cb_diag['php'] ); ?></td>
			</tr>
		</table>
	</div>
</div>

<div class="cbridge-card">
	<h3><?php esc_html_e( 'آخرین رویدادها', 'content-bridge' ); ?></h3>
	<?php if ( empty( $cb_recent ) ) : ?>
		<p class="cbridge-empty"><?php esc_html_e( 'هنوز رویدادی ثبت نشده است.', 'content-bridge' ); ?></p>
	<?php else : ?>
		<table class="cbridge-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'زمان', 'content-bridge' ); ?></th>
					<th><?php esc_html_e( 'رویداد', 'content-bridge' ); ?></th>
					<th><?php esc_html_e( 'وضعیت', 'content-bridge' ); ?></th>
					<th><?php esc_html_e( 'شرح', 'content-bridge' ); ?></th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $cb_recent as $cb_row ) : ?>
					<tr>
						<td dir="ltr"><?php echo esc_html( $cb_row->created_at ); ?></td>
						<td><code><?php echo esc_html( $cb_row->action ); ?></code></td>
						<td><span class="cbridge-code s<?php echo esc_attr( substr( (string) $cb_row->status, 0, 1 ) ); ?>"><?php echo esc_html( $cb_row->status ); ?></span></td>
						<td><?php echo esc_html( wp_trim_words( (string) $cb_row->message, 12 ) ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	<?php endif; ?>
</div>
