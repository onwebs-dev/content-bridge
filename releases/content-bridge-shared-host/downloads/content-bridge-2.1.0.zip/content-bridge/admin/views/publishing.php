<?php
/**
 * تب انتشار.
 *
 * @package Content_Bridge
 */

defined( 'ABSPATH' ) || exit;

$cb_types = get_post_types( array( 'public' => true ), 'objects' );
$cb_sel   = (array) cbridge_opt( 'post_types' );
?>

<form method="post">
	<?php CBridge_Admin::form_fields( 'save_settings' ); ?>
	<input type="hidden" name="cbridge_tab" value="publishing">

	<h2 class="cbridge-h2"><?php esc_html_e( 'رفتار انتشار', 'content-bridge' ); ?></h2>

	<div class="cbridge-card">
		<div class="cbridge-field cbridge-toggle-row">
			<label class="cbridge-switch">
				<input type="checkbox" name="cbridge[allow_publish]" value="1" <?php checked( 1, (int) cbridge_opt( 'allow_publish' ) ); ?>>
				<span class="slider"></span>
			</label>
			<div>
				<strong><?php esc_html_e( 'اجازه‌ی انتشار مستقیم', 'content-bridge' ); ?></strong>
				<p class="cbridge-hint">
					<?php esc_html_e( 'خاموش (پیش‌فرض امن): هر مطلبی که برسد پیش‌نویس می‌ماند و پاسخ پرچم downgraded می‌گیرد. تا وقتی خروجی ایجنت را ندیده‌اید، خاموش نگه دارید.', 'content-bridge' ); ?>
				</p>
			</div>
		</div>

		<div class="cbridge-field cbridge-toggle-row">
			<label class="cbridge-switch">
				<input type="checkbox" name="cbridge[create_terms]" value="1" <?php checked( 1, (int) cbridge_opt( 'create_terms' ) ); ?>>
				<span class="slider"></span>
			</label>
			<div>
				<strong><?php esc_html_e( 'ساخت خودکار دسته و برچسب', 'content-bridge' ); ?></strong>
				<p class="cbridge-hint">
					<?php esc_html_e( 'ایجنت دسته را با نام می‌فرستد. اگر خاموش باشد، ترم‌های ناموجود نادیده گرفته و در warnings گزارش می‌شوند.', 'content-bridge' ); ?>
				</p>
			</div>
		</div>

		<div class="cbridge-field cbridge-toggle-row">
			<label class="cbridge-switch">
				<input type="checkbox" name="cbridge[enable_ajax]" value="1" <?php checked( 1, (int) cbridge_opt( 'enable_ajax' ) ); ?>>
				<span class="slider"></span>
			</label>
			<div>
				<strong><?php esc_html_e( 'مسیر پشتیبان admin-ajax', 'content-bridge' ); ?></strong>
				<p class="cbridge-hint">
					<?php esc_html_e( 'اگر هاست یا افزونه‌ی امنیتی مسیر wp-json را بسته باشد، این مسیر دوم کار را نجات می‌دهد. احراز هویتش دقیقاً همان توکن است.', 'content-bridge' ); ?>
				</p>
			</div>
		</div>
	</div>

	<h2 class="cbridge-h2"><?php esc_html_e( 'محدوده و محدودیت', 'content-bridge' ); ?></h2>

	<div class="cbridge-card">
		<div class="cbridge-field">
			<label class="cbridge-label"><?php esc_html_e( 'نوع پست مجاز', 'content-bridge' ); ?></label>
			<div class="cbridge-checks">
				<?php foreach ( $cb_types as $cb_t ) : ?>
					<label class="cbridge-check">
						<input type="checkbox" name="cbridge[post_types][]" value="<?php echo esc_attr( $cb_t->name ); ?>"
							<?php checked( in_array( $cb_t->name, $cb_sel, true ) ); ?>>
						<?php echo esc_html( $cb_t->labels->singular_name ); ?>
						<code><?php echo esc_html( $cb_t->name ); ?></code>
					</label>
				<?php endforeach; ?>
			</div>
			<p class="cbridge-hint"><?php esc_html_e( 'هر نوع پستی که تیک نخورده باشد، درخواستش با خطای ۴۰۰ رد می‌شود.', 'content-bridge' ); ?></p>
		</div>

		<div class="cbridge-field">
			<label class="cbridge-label" for="cb-author"><?php esc_html_e( 'نویسنده‌ی پیش‌فرض', 'content-bridge' ); ?></label>
			<?php
			wp_dropdown_users(
				array(
					'name'             => 'cbridge[default_author]',
					'id'               => 'cb-author',
					'selected'         => (int) cbridge_opt( 'default_author' ),
					'show_option_none' => __( '— نخستین مدیر —', 'content-bridge' ),
					'option_none_value' => 0,
					'class'            => 'cbridge-input',
				)
			);
			?>
			<p class="cbridge-hint"><?php esc_html_e( 'وقتی استفاده می‌شود که نویسنده‌ی ارسالی روی سایت پیدا نشود. بایلاین انسانی برای سئو مهم است — نویسنده‌ی واقعی بسازید، نه «ادمین».', 'content-bridge' ); ?></p>
		</div>

		<div class="cbridge-field cbridge-inline">
			<div>
				<label class="cbridge-label" for="cb-rate"><?php esc_html_e( 'سقف نرخ (ساخت در ساعت)', 'content-bridge' ); ?></label>
				<input type="number" id="cb-rate" class="cbridge-input small" name="cbridge[rate_limit]" min="0" max="500"
					value="<?php echo esc_attr( (int) cbridge_opt( 'rate_limit' ) ); ?>">
				<p class="cbridge-hint"><?php esc_html_e( 'صفر یعنی بدون محدودیت. شمارش از جدول گزارش‌ها انجام می‌شود، نه از کش.', 'content-bridge' ); ?></p>
			</div>
			<div>
				<label class="cbridge-label" for="cb-logdays"><?php esc_html_e( 'نگهداری گزارش (روز)', 'content-bridge' ); ?></label>
				<input type="number" id="cb-logdays" class="cbridge-input small" name="cbridge[log_days]" min="1" max="365"
					value="<?php echo esc_attr( (int) cbridge_opt( 'log_days' ) ); ?>">
				<p class="cbridge-hint"><?php esc_html_e( 'ردیف‌های قدیمی‌تر روزانه هرس می‌شوند.', 'content-bridge' ); ?></p>
			</div>
		</div>
	</div>

	<p class="cbridge-submit">
		<button type="submit" class="button button-primary button-hero"><?php esc_html_e( 'ذخیره‌ی تنظیمات', 'content-bridge' ); ?></button>
	</p>
</form>
