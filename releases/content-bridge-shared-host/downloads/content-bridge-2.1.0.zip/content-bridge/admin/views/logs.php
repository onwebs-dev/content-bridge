<?php
/**
 * تب گزارش‌ها.
 *
 * @package Content_Bridge
 */

defined( 'ABSPATH' ) || exit;

$cb_filter = isset( $_GET['f'] ) ? sanitize_key( wp_unslash( $_GET['f'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
$cb_rows   = CBridge_Log::recent( 100, $cb_filter );
$cb_kinds  = array(
	''             => __( 'همه', 'content-bridge' ),
	'post.create'  => __( 'ساخت', 'content-bridge' ),
	'post.update'  => __( 'به‌روزرسانی', 'content-bridge' ),
	'post.invalid' => __( 'ورودی نامعتبر', 'content-bridge' ),
	'post.error'   => __( 'خطا', 'content-bridge' ),
	'auth.fail'    => __( 'خطای احراز', 'content-bridge' ),
	'rate.block'   => __( 'سقف نرخ', 'content-bridge' ),
);
?>

<h2 class="cbridge-h2"><?php esc_html_e( 'گزارش رویدادها', 'content-bridge' ); ?></h2>

<div class="cbridge-filters">
	<?php foreach ( $cb_kinds as $cb_k => $cb_lbl ) : ?>
		<a class="cbridge-chip <?php echo $cb_filter === $cb_k ? 'active' : ''; ?>"
			href="<?php echo esc_url( admin_url( 'admin.php?page=content-bridge&tab=logs' . ( $cb_k ? '&f=' . $cb_k : '' ) ) ); ?>">
			<?php echo esc_html( $cb_lbl ); ?>
		</a>
	<?php endforeach; ?>
</div>

<div class="cbridge-card">
	<?php if ( empty( $cb_rows ) ) : ?>
		<p class="cbridge-empty"><?php esc_html_e( 'رویدادی ثبت نشده است.', 'content-bridge' ); ?></p>
	<?php else : ?>
		<table class="cbridge-table">
			<thead>
				<tr>
					<th><?php esc_html_e( 'زمان (UTC)', 'content-bridge' ); ?></th>
					<th><?php esc_html_e( 'رویداد', 'content-bridge' ); ?></th>
					<th><?php esc_html_e( 'کد', 'content-bridge' ); ?></th>
					<th><?php esc_html_e( 'شناسه بیرونی', 'content-bridge' ); ?></th>
					<th><?php esc_html_e( 'مطلب', 'content-bridge' ); ?></th>
					<th><?php esc_html_e( 'شرح', 'content-bridge' ); ?></th>
					<th>IP</th>
				</tr>
			</thead>
			<tbody>
				<?php foreach ( $cb_rows as $cb_r ) : ?>
					<tr>
						<td dir="ltr" class="cbridge-nowrap"><?php echo esc_html( $cb_r->created_at ); ?></td>
						<td><code><?php echo esc_html( $cb_r->action ); ?></code></td>
						<td><span class="cbridge-code s<?php echo esc_attr( substr( (string) $cb_r->status, 0, 1 ) ); ?>"><?php echo esc_html( $cb_r->status ); ?></span></td>
						<td dir="ltr" class="cbridge-muted"><?php echo esc_html( $cb_r->external_id ); ?></td>
						<td>
							<?php if ( $cb_r->post_id ) : ?>
								<a href="<?php echo esc_url( (string) get_edit_post_link( (int) $cb_r->post_id ) ); ?>">#<?php echo esc_html( (string) $cb_r->post_id ); ?></a>
							<?php else : ?>
								—
							<?php endif; ?>
						</td>
						<td><?php echo esc_html( (string) $cb_r->message ); ?></td>
						<td dir="ltr" class="cbridge-muted"><?php echo esc_html( (string) $cb_r->ip ); ?></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>
	<?php endif; ?>
</div>

<form method="post" onsubmit="return confirm('<?php echo esc_js( __( 'همه‌ی گزارش‌ها پاک شوند؟', 'content-bridge' ) ); ?>');">
	<?php CBridge_Admin::form_fields( 'clear_logs' ); ?>
	<button type="submit" class="button cbridge-danger"><?php esc_html_e( 'پاک‌کردن گزارش‌ها', 'content-bridge' ); ?></button>
	<span class="cbridge-hint">
		<?php
		printf(
			/* translators: %d: days */
			esc_html__( 'ردیف‌های قدیمی‌تر از %d روز خودکار هرس می‌شوند.', 'content-bridge' ),
			(int) cbridge_opt( 'log_days' )
		);
		?>
	</span>
</form>
