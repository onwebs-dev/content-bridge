<?php
/**
 * تب تشخیص — همان چیزی که ۹۰٪ تیکت‌های پشتیبانی را حل می‌کند.
 *
 * @package Content_Bridge
 */

defined( 'ABSPATH' ) || exit;

$cb_d = CBridge_Rest::diagnostics();
?>

<h2 class="cbridge-h2"><?php esc_html_e( 'سلامت محیط', 'content-bridge' ); ?></h2>

<div class="cbridge-card">
	<table class="cbridge-table cbridge-diag">
		<tbody>
			<?php
			$cb_rows = array(
				array(
					__( 'هدر احراز هویت به PHP می‌رسد', 'content-bridge' ),
					$cb_d['auth_header_received'],
					__( 'شایع‌ترین مشکل روی هاست اشتراکی. اگر قرمز است، راه‌حل پایین را اعمال کنید.', 'content-bridge' ),
				),
				array( __( 'اتصال امن HTTPS', 'content-bridge' ), $cb_d['https'], __( 'بدون SSL بعضی افزونه‌ها و مرورگرها محدودیت می‌گذارند.', 'content-bridge' ) ),
				array( __( 'پوشه‌ی آپلود قابل نوشتن', 'content-bridge' ), $cb_d['uploads_writable'], __( 'برای تصویر شاخص لازم است.', 'content-bridge' ) ),
				array( __( 'مسیر پشتیبان فعال', 'content-bridge' ), $cb_d['ajax_fallback'], __( 'اگر wp-json بسته شود، این مسیر جایگزین است.', 'content-bridge' ) ),
				array( __( 'افزونه‌ی سئو شناسایی شد', 'content-bridge' ), 'none' !== $cb_d['seo_plugin'], CBridge_Seo::label( $cb_d['seo_plugin'] ) ),
				array( __( 'انتشار مستقیم فعال', 'content-bridge' ), $cb_d['allow_publish'], __( 'اگر خاموش باشد همه‌چیز پیش‌نویس می‌ماند — علت شایع «چرا منتشر نشد».', 'content-bridge' ) ),
				array( __( 'ساخت خودکار ترم‌ها', 'content-bridge' ), $cb_d['can_create_terms'], __( 'برای دسته‌بندی با نام لازم است.', 'content-bridge' ) ),
			);
			foreach ( $cb_rows as $cb_r ) :
				?>
				<tr>
					<td class="cbridge-diag-state">
						<span class="cbridge-dot <?php echo $cb_r[1] ? 'ok' : 'no'; ?>"></span>
					</td>
					<td><strong><?php echo esc_html( $cb_r[0] ); ?></strong></td>
					<td class="cbridge-muted"><?php echo esc_html( $cb_r[2] ); ?></td>
				</tr>
			<?php endforeach; ?>
		</tbody>
	</table>
</div>

<?php if ( ! $cb_d['auth_header_received'] ) : ?>
<div class="cbridge-card cbridge-fix">
	<h3><?php esc_html_e( 'راه‌حل: سرور هدر Authorization را حذف می‌کند', 'content-bridge' ); ?></h3>
	<p><?php esc_html_e( 'این خط را به فایل .htaccess ریشه‌ی سایت اضافه کنید:', 'content-bridge' ); ?></p>
	<pre class="cbridge-pre" dir="ltr">SetEnvIf Authorization "(.*)" HTTP_AUTHORIZATION=$1</pre>
	<p class="cbridge-hint">
		<?php esc_html_e( 'اگر دسترسی به .htaccess ندارید یا سرور NGINX است، راه دوم این است که ایجنت به‌جای Authorization از هدر X-CB-Token استفاده کند — افزونه هر دو را می‌پذیرد.', 'content-bridge' ); ?>
	</p>
</div>
<?php endif; ?>

<div class="cbridge-card">
	<h3><?php esc_html_e( 'تست زنده‌ی اندپوینت', 'content-bridge' ); ?></h3>
	<p class="cbridge-hint"><?php esc_html_e( 'اندپوینت ping را از مرورگر شما صدا می‌زند و پاسخ خام را نشان می‌دهد.', 'content-bridge' ); ?></p>
	<p><button type="button" class="button" id="cbridge-ping-btn"><?php esc_html_e( 'اجرای تست', 'content-bridge' ); ?></button></p>
	<pre class="cbridge-pre" id="cbridge-ping-out" dir="ltr" style="display:none"></pre>
</div>

<div class="cbridge-card">
	<h3><?php esc_html_e( 'خطاهای رایج و علتشان', 'content-bridge' ); ?></h3>
	<table class="cbridge-table">
		<thead>
			<tr>
				<th><?php esc_html_e( 'نشانه', 'content-bridge' ); ?></th>
				<th><?php esc_html_e( 'علت', 'content-bridge' ); ?></th>
			</tr>
		</thead>
		<tbody>
			<tr><td><code>404</code> <?php esc_html_e( 'روی اندپوینت', 'content-bridge' ); ?></td><td><?php esc_html_e( 'توکن ساخته نشده — اندپوینت عمداً وجود ندارد.', 'content-bridge' ); ?></td></tr>
			<tr><td><code>401</code></td><td><?php esc_html_e( 'توکن غلط، یا سرور هدر را حذف کرده.', 'content-bridge' ); ?></td></tr>
			<tr><td><code>429</code></td><td><?php esc_html_e( 'سقف نرخ ساعتی پر شده.', 'content-bridge' ); ?></td></tr>
			<tr><td><code>413</code></td><td><?php esc_html_e( 'بدنه بیش از ۸ مگابایت — معمولاً تصویر base64 بزرگ.', 'content-bridge' ); ?></td></tr>
			<tr><td><?php esc_html_e( 'مطلب پیش‌نویس ماند', 'content-bridge' ); ?></td><td><?php esc_html_e( 'اجازه‌ی انتشار مستقیم خاموش است (تب انتشار).', 'content-bridge' ); ?></td></tr>
			<tr><td><?php esc_html_e( 'جدول یا لینک از متن حذف شد', 'content-bridge' ); ?></td><td><?php esc_html_e( 'sanitizer وردپرس تگ غیرمجاز را حذف کرده؛ پاسخ پرچم content_stripped می‌گیرد.', 'content-bridge' ); ?></td></tr>
			<tr><td><?php esc_html_e( 'کارت شبکه‌ی اجتماعی بدون تصویر', 'content-bridge' ); ?></td><td><?php esc_html_e( 'تصویر WebP است؛ لینکدین و تلگرام آن را نشان نمی‌دهند. JPEG بفرستید.', 'content-bridge' ); ?></td></tr>
		</tbody>
	</table>
</div>
