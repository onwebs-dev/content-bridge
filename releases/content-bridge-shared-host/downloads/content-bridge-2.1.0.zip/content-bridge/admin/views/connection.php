<?php
/**
 * تب اتصال و توکن.
 *
 * @package Content_Bridge
 */

defined( 'ABSPATH' ) || exit;

$cb_new  = get_transient( 'cbridge_new_token' );
$cb_made = get_option( 'cbridge_token_created', '' );
$cb_rest = rest_url( CBRIDGE_NS . '/' );
$cb_ajax = admin_url( 'admin-ajax.php' );
?>

<h2 class="cbridge-h2"><?php esc_html_e( 'توکن دسترسی', 'content-bridge' ); ?></h2>

<?php if ( $cb_new ) : ?>
	<div class="cbridge-token-box">
		<p class="cbridge-token-title"><?php esc_html_e( 'توکن تازه ساخته شد — همین حالا کپی کنید', 'content-bridge' ); ?></p>
		<div class="cbridge-copy-row">
			<input type="text" readonly dir="ltr" id="cbridge-token" value="<?php echo esc_attr( $cb_new ); ?>">
			<button type="button" class="button cbridge-copy" data-target="#cbridge-token"><?php esc_html_e( 'کپی', 'content-bridge' ); ?></button>
		</div>
		<p class="cbridge-hint">
			<?php esc_html_e( 'این مقدار فقط همین یک بار نمایش داده می‌شود. در دیتابیس فقط هشِ آن ذخیره شده است، پس اگر گمش کنید باید توکن تازه بسازید.', 'content-bridge' ); ?>
		</p>
	</div>
	<?php delete_transient( 'cbridge_new_token' ); ?>
<?php endif; ?>

<div class="cbridge-grid-2">
	<div class="cbridge-card">
		<h3><?php esc_html_e( 'وضعیت توکن', 'content-bridge' ); ?></h3>
		<?php if ( CBridge_Auth::is_configured() ) : ?>
			<p class="cbridge-badge on"><?php esc_html_e( 'تنظیم شده', 'content-bridge' ); ?></p>
			<?php if ( $cb_made ) : ?>
				<p class="cbridge-hint"><?php esc_html_e( 'تاریخ ساخت:', 'content-bridge' ); ?> <span dir="ltr"><?php echo esc_html( $cb_made ); ?></span></p>
			<?php endif; ?>
		<?php else : ?>
			<p class="cbridge-badge off"><?php esc_html_e( 'تنظیم نشده', 'content-bridge' ); ?></p>
			<p class="cbridge-hint">
				<?php esc_html_e( 'تا وقتی توکن نسازید، اندپوینت عمداً ۴۰۴ می‌دهد — یعنی از بیرون اصلاً «وجود ندارد».', 'content-bridge' ); ?>
			</p>
		<?php endif; ?>

		<form method="post" class="cbridge-actions">
			<?php CBridge_Admin::form_fields( 'generate_token' ); ?>
			<button type="submit" class="button button-primary">
				<?php echo CBridge_Auth::is_configured() ? esc_html__( 'ساخت توکن تازه', 'content-bridge' ) : esc_html__( 'ساخت توکن', 'content-bridge' ); ?>
			</button>
		</form>

		<?php if ( CBridge_Auth::is_configured() ) : ?>
			<form method="post" class="cbridge-actions" onsubmit="return confirm('<?php echo esc_js( __( 'مطمئنید؟ ارتباط ایجنت قطع می‌شود.', 'content-bridge' ) ); ?>');">
				<?php CBridge_Admin::form_fields( 'revoke_token' ); ?>
				<button type="submit" class="button cbridge-danger"><?php esc_html_e( 'ابطال توکن', 'content-bridge' ); ?></button>
			</form>
		<?php endif; ?>
	</div>

	<div class="cbridge-card">
		<h3><?php esc_html_e( 'آدرس‌های اندپوینت', 'content-bridge' ); ?></h3>
		<table class="cbridge-kv">
			<tr>
				<th>POST</th>
				<td><code dir="ltr"><?php echo esc_html( $cb_rest . 'posts' ); ?></code></td>
			</tr>
			<tr>
				<th>GET</th>
				<td><code dir="ltr"><?php echo esc_html( $cb_rest . 'posts' ); ?></code></td>
			</tr>
			<tr>
				<th>PING</th>
				<td><code dir="ltr"><?php echo esc_html( $cb_rest . 'ping' ); ?></code></td>
			</tr>
			<tr>
				<th><?php esc_html_e( 'پشتیبان', 'content-bridge' ); ?></th>
				<td><code dir="ltr"><?php echo esc_html( $cb_ajax . '?action=cbridge_publish' ); ?></code></td>
			</tr>
		</table>
		<p class="cbridge-hint">
			<?php esc_html_e( 'مسیر پشتیبان وقتی به کار می‌آید که هاست یا افزونه‌ی امنیتی، مسیر wp-json را بسته باشد.', 'content-bridge' ); ?>
		</p>
	</div>
</div>

<div class="cbridge-card">
	<h3><?php esc_html_e( 'نمونه‌ی فراخوانی', 'content-bridge' ); ?></h3>
	<p class="cbridge-hint"><?php esc_html_e( 'هدر دوم برای سرورهایی است که هدر Authorization را حذف می‌کنند — هر دو پذیرفته می‌شوند.', 'content-bridge' ); ?></p>
	<pre class="cbridge-pre" dir="ltr">curl -X POST "<?php echo esc_html( $cb_rest . 'posts' ); ?>" \
  -H "Authorization: Bearer YOUR_TOKEN" \
  -H "X-CB-Token: YOUR_TOKEN" \
  -H "Content-Type: application/json" \
  -d @article.json</pre>
</div>
