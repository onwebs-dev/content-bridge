<?php
/**
 * پنل مدیریت — منوی اختصاصی در سایدبار + صفحه‌ی تنظیمات تب‌بندی‌شده.
 *
 * @package Content_Bridge
 */

defined( 'ABSPATH' ) || exit;

/** رابط کاربری مدیریت. */
class CBridge_Admin {

	const SLUG = 'content-bridge';
	const CAP  = 'manage_options';

	/** تب‌های صفحه. */
	private static function tabs() {
		return array(
			'dashboard'   => array( 'داشبورد', 'dashicons-chart-area' ),
			'connection'  => array( 'اتصال و توکن', 'dashicons-admin-network' ),
			'publishing'  => array( 'انتشار', 'dashicons-migrate' ),
			'seo'         => array( 'سئو', 'dashicons-search' ),
			'diagnostics' => array( 'تشخیص', 'dashicons-heart' ),
			'logs'        => array( 'گزارش‌ها', 'dashicons-list-view' ),
			'help'        => array( 'راهنما', 'dashicons-editor-help' ),
		);
	}

	/** ثبت هوک‌ها. */
	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'menu' ) );
		add_action( 'admin_init', array( __CLASS__, 'handle_actions' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'assets' ) );
	}

	/** منوی سایدبار. */
	public static function menu() {
		add_menu_page(
			__( 'Content Bridge', 'content-bridge' ),
			__( 'Content Bridge', 'content-bridge' ),
			self::CAP,
			self::SLUG,
			array( __CLASS__, 'render' ),
			'dashicons-rest-api',
			58
		);
	}

	/**
	 * بارگذاری استایل و اسکریپت — فقط در صفحه‌ی خودمان.
	 *
	 * @param string $hook شناسه‌ی صفحه.
	 */
	public static function assets( $hook ) {
		if ( false === strpos( (string) $hook, self::SLUG ) ) {
			return;
		}
		wp_enqueue_style( 'cbridge-admin', CBRIDGE_URL . 'admin/css/admin.css', array(), CBRIDGE_VERSION );
		wp_enqueue_script( 'cbridge-admin', CBRIDGE_URL . 'admin/js/admin.js', array(), CBRIDGE_VERSION, true );
		wp_localize_script(
			'cbridge-admin',
			'CBridgeAdmin',
			array(
				'restUrl' => esc_url_raw( rest_url( CBRIDGE_NS . '/ping' ) ),
				'copied'  => __( 'کپی شد', 'content-bridge' ),
			)
		);
	}

	/** پردازش فرم‌ها. */
	public static function handle_actions() {
		if ( ! isset( $_POST['cbridge_action'] ) || ! current_user_can( self::CAP ) ) {
			return;
		}
		$action = sanitize_key( wp_unslash( $_POST['cbridge_action'] ) );
		check_admin_referer( 'cbridge_' . $action );

		$redirect = admin_url( 'admin.php?page=' . self::SLUG );

		if ( 'save_settings' === $action ) {
			$tab = isset( $_POST['cbridge_tab'] ) ? sanitize_key( wp_unslash( $_POST['cbridge_tab'] ) ) : 'publishing';
			self::save_settings();
			wp_safe_redirect( add_query_arg( array( 'tab' => $tab, 'msg' => 'saved' ), $redirect ) );
			exit;
		}

		if ( 'generate_token' === $action ) {
			$raw = CBridge_Auth::generate();
			set_transient( 'cbridge_new_token', $raw, 5 * MINUTE_IN_SECONDS );
			wp_safe_redirect( add_query_arg( array( 'tab' => 'connection', 'msg' => 'token' ), $redirect ) );
			exit;
		}

		if ( 'revoke_token' === $action ) {
			CBridge_Auth::revoke();
			wp_safe_redirect( add_query_arg( array( 'tab' => 'connection', 'msg' => 'revoked' ), $redirect ) );
			exit;
		}

		if ( 'clear_logs' === $action ) {
			global $wpdb;
			$table = CBridge_Log::table();
			$wpdb->query( "TRUNCATE TABLE {$table}" ); // phpcs:ignore
			wp_safe_redirect( add_query_arg( array( 'tab' => 'logs', 'msg' => 'cleared' ), $redirect ) );
			exit;
		}
	}

	/** ذخیره‌ی تنظیمات. */
	private static function save_settings() {
		$in  = isset( $_POST['cbridge'] ) ? (array) wp_unslash( $_POST['cbridge'] ) : array(); // phpcs:ignore
		$cur = get_option( 'cbridge_settings', cbridge_defaults() );
		if ( ! is_array( $cur ) ) {
			$cur = cbridge_defaults();
		}

		if ( isset( $in['allow_publish'] ) ) {
			$cur['allow_publish'] = (int) ! empty( $in['allow_publish'] );
		}
		if ( isset( $in['enable_ajax'] ) ) {
			$cur['enable_ajax'] = (int) ! empty( $in['enable_ajax'] );
		}
		if ( isset( $in['create_terms'] ) ) {
			$cur['create_terms'] = (int) ! empty( $in['create_terms'] );
		}
		if ( isset( $in['default_author'] ) ) {
			$cur['default_author'] = (int) $in['default_author'];
		}
		if ( isset( $in['rate_limit'] ) ) {
			$cur['rate_limit'] = max( 0, min( 500, (int) $in['rate_limit'] ) );
		}
		if ( isset( $in['log_days'] ) ) {
			$cur['log_days'] = max( 1, min( 365, (int) $in['log_days'] ) );
		}
		if ( isset( $in['post_types'] ) && is_array( $in['post_types'] ) ) {
			$cur['post_types'] = array_values( array_filter( array_map( 'sanitize_key', $in['post_types'] ) ) );
			if ( empty( $cur['post_types'] ) ) {
				$cur['post_types'] = array( 'post' );
			}
		}
		if ( isset( $in['faq_output'] ) ) {
			$v                  = sanitize_key( $in['faq_output'] );
			$cur['faq_output']  = in_array( $v, array( 'append', 'schema_only', 'off' ), true ) ? $v : 'append';
		}
		if ( isset( $in['seo_override'] ) ) {
			$v                   = sanitize_key( $in['seo_override'] );
			$allowed             = array( 'auto', 'yoast', 'rankmath', 'seopress', 'aioseo', 'none' );
			$cur['seo_override'] = in_array( $v, $allowed, true ) ? $v : 'auto';
		}

		update_option( 'cbridge_settings', $cur );
	}

	/** رندر صفحه. */
	public static function render() {
		if ( ! current_user_can( self::CAP ) ) {
			return;
		}
		$tabs    = self::tabs();
		$current = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'dashboard'; // phpcs:ignore WordPress.Security.NonceVerification
		if ( ! isset( $tabs[ $current ] ) ) {
			$current = 'dashboard';
		}
		$msg = isset( $_GET['msg'] ) ? sanitize_key( wp_unslash( $_GET['msg'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
		?>
		<div class="wrap cbridge-wrap">

			<div class="cbridge-header">
				<div class="cbridge-brand">
					<span class="cbridge-logo" aria-hidden="true">CB</span>
					<div>
						<h1>Content Bridge</h1>
						<p class="cbridge-sub">
							<?php esc_html_e( 'پل انتشار خودکار محتوا', 'content-bridge' ); ?>
							<span class="cbridge-ver">v<?php echo esc_html( CBRIDGE_VERSION ); ?></span>
						</p>
					</div>
				</div>
				<div class="cbridge-status-pill <?php echo CBridge_Auth::is_configured() ? 'is-on' : 'is-off'; ?>">
					<?php echo CBridge_Auth::is_configured() ? esc_html__( 'اندپوینت فعال', 'content-bridge' ) : esc_html__( 'اندپوینت غیرفعال', 'content-bridge' ); ?>
				</div>
			</div>

			<?php self::notice( $msg ); ?>

			<nav class="cbridge-tabs">
				<?php foreach ( $tabs as $key => $meta ) : ?>
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=' . self::SLUG . '&tab=' . $key ) ); ?>"
						class="cbridge-tab <?php echo $current === $key ? 'active' : ''; ?>">
						<span class="dashicons <?php echo esc_attr( $meta[1] ); ?>"></span>
						<?php echo esc_html( $meta[0] ); ?>
					</a>
				<?php endforeach; ?>
			</nav>

			<div class="cbridge-panel">
				<?php
				$file = CBRIDGE_DIR . 'admin/views/' . $current . '.php';
				if ( file_exists( $file ) ) {
					include $file;
				}
				?>
			</div>

			<p class="cbridge-footer">
				<?php
				printf(
					/* translators: %s: author link */
					esc_html__( 'توسعه: %s', 'content-bridge' ),
					'<a href="https://onwebs.ir" target="_blank" rel="noopener">امیرحسین مقتدر — شرکت ویرا وب آریا</a>'
				);
				?>
			</p>
		</div>
		<?php
	}

	/**
	 * پیام‌های وضعیت.
	 *
	 * @param string $msg کلید پیام.
	 */
	private static function notice( $msg ) {
		if ( 'saved' === $msg ) {
			echo '<div class="cbridge-notice ok">' . esc_html__( 'تنظیمات ذخیره شد.', 'content-bridge' ) . '</div>';
		} elseif ( 'revoked' === $msg ) {
			echo '<div class="cbridge-notice warn">' . esc_html__( 'توکن باطل شد. اندپوینت تا تولید توکن تازه، ۴۰۴ می‌دهد.', 'content-bridge' ) . '</div>';
		} elseif ( 'cleared' === $msg ) {
			echo '<div class="cbridge-notice ok">' . esc_html__( 'گزارش‌ها پاک شد.', 'content-bridge' ) . '</div>';
		}
	}

	/**
	 * فیلد مخفی امنیتی فرم.
	 *
	 * @param string $action نام عملیات.
	 */
	public static function form_fields( $action ) {
		wp_nonce_field( 'cbridge_' . $action );
		echo '<input type="hidden" name="cbridge_action" value="' . esc_attr( $action ) . '">';
	}
}
