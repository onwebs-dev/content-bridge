/**
 * Content Bridge — اسکریپت پنل مدیریت.
 * بدون هیچ وابستگی؛ jQuery هم لازم نیست.
 */
( function () {
	'use strict';

	/** کپی مقدار یک ورودی در کلیپ‌بورد. */
	function bindCopy() {
		document.querySelectorAll( '.cbridge-copy' ).forEach( function ( btn ) {
			btn.addEventListener( 'click', function () {
				var input = document.querySelector( btn.dataset.target );
				if ( ! input ) {
					return;
				}
				input.select();
				input.setSelectionRange( 0, 99999 );

				var done = function () {
					var old = btn.textContent;
					btn.textContent = ( window.CBridgeAdmin && window.CBridgeAdmin.copied ) || 'copied';
					setTimeout( function () {
						btn.textContent = old;
					}, 1600 );
				};

				if ( navigator.clipboard && navigator.clipboard.writeText ) {
					navigator.clipboard.writeText( input.value ).then( done, function () {
						document.execCommand( 'copy' );
						done();
					} );
				} else {
					document.execCommand( 'copy' );
					done();
				}
			} );
		} );
	}

	/** تست زنده‌ی اندپوینت ping. */
	function bindPing() {
		var btn = document.getElementById( 'cbridge-ping-btn' );
		var out = document.getElementById( 'cbridge-ping-out' );
		if ( ! btn || ! out || ! window.CBridgeAdmin ) {
			return;
		}

		btn.addEventListener( 'click', function () {
			btn.disabled = true;
			out.style.display = 'block';
			out.textContent = '…';

			fetch( window.CBridgeAdmin.restUrl, {
				credentials: 'same-origin',
				headers: { Accept: 'application/json' }
			} )
				.then( function ( r ) {
					return r.text().then( function ( t ) {
						var parsed;
						try {
							parsed = JSON.stringify( JSON.parse( t ), null, 2 );
						} catch ( e ) {
							parsed = t;
						}
						return 'HTTP ' + r.status + '\n\n' + parsed;
					} );
				} )
				.then( function ( text ) {
					out.textContent = text;
				} )
				.catch( function ( err ) {
					out.textContent = 'خطا: ' + err.message;
				} )
				.finally( function () {
					btn.disabled = false;
				} );
		} );
	}

	if ( 'loading' === document.readyState ) {
		document.addEventListener( 'DOMContentLoaded', function () {
			bindCopy();
			bindPing();
		} );
	} else {
		bindCopy();
		bindPing();
	}
} )();
