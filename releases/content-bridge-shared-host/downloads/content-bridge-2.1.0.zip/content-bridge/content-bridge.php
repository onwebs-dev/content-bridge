<?php
/**
 * Plugin Name:       Content Bridge
 * Plugin URI:        https://onwebs.ir/content-bridge
 * Description:       پل انتشار خودکار محتوا برای وردپرس — دریافت مقاله از ایجنت محتوا، تصویر شاخص، دسته و برچسب با نام، پرکردن کامل فیلدهای سئو (Yoast / Rank Math / SEOPress / AIOSEO)، اسکیمای FAQ، و جلوگیری از انتشار تکراری.
 * Version:           2.1.0
 * Requires at least: 5.6
 * Tested up to:      7.0
 * Requires PHP:      7.4
 * Author:            امیرحسین مقتدر (شرکت ویرا وب آریا - onwebs.ir)
 * Author URI:        https://onwebs.ir
 * License:           GPLv2 or later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       content-bridge
 * Domain Path:       /languages
 *
 * @package Content_Bridge
 */

defined( 'ABSPATH' ) || exit;

define( 'CBRIDGE_VERSION', '2.1.0' );
define( 'CBRIDGE_FILE', __FILE__ );
define( 'CBRIDGE_DIR', plugin_dir_path( __FILE__ ) );
define( 'CBRIDGE_URL', plugin_dir_url( __FILE__ ) );
define( 'CBRIDGE_NS', 'cbridge/v1' );

/** سقف حجم بدنه — دستی چک می‌شود چون محدودیت‌های آپلود به JSON اعمال نمی‌شود. */
define( 'CBRIDGE_MAX_BODY', 8 * 1024 * 1024 );

require_once CBRIDGE_DIR . 'includes/class-cbridge-log.php';
require_once CBRIDGE_DIR . 'includes/class-cbridge-auth.php';
require_once CBRIDGE_DIR . 'includes/class-cbridge-validator.php';
require_once CBRIDGE_DIR . 'includes/class-cbridge-media.php';
require_once CBRIDGE_DIR . 'includes/class-cbridge-taxonomy.php';
require_once CBRIDGE_DIR . 'includes/class-cbridge-seo.php';
require_once CBRIDGE_DIR . 'includes/class-cbridge-faq.php';
require_once CBRIDGE_DIR . 'includes/class-cbridge-handler.php';
require_once CBRIDGE_DIR . 'includes/class-cbridge-rest.php';
require_once CBRIDGE_DIR . 'includes/class-cbridge-ajax.php';

if ( is_admin() ) {
	require_once CBRIDGE_DIR . 'admin/class-cbridge-admin.php';
}

/**
 * پیش‌فرض گزینه‌ها. هر گزینه‌ی تازه را اینجا اضافه کن تا نصب‌های قدیمی
 * بعد از به‌روزرسانی مقدار معتبر داشته باشند.
 *
 * @return array<string,mixed>
 */
function cbridge_defaults() {
	return array(
		'allow_publish'  => 0,
		'default_author' => 0,
		'post_types'     => array( 'post' ),
		'rate_limit'     => 20,
		'enable_ajax'    => 1,
		'create_terms'   => 1,
		'log_days'       => 30,
		'faq_output'     => 'append', // append | schema_only | off
		'seo_override'   => 'auto',   // auto | yoast | rankmath | seopress | aioseo | none
	);
}

/**
 * خواندن یک گزینه با پیش‌فرض امن.
 *
 * @param string $key نام گزینه.
 * @return mixed
 */
function cbridge_opt( $key ) {
	$all      = get_option( 'cbridge_settings', array() );
	$defaults = cbridge_defaults();
	if ( ! is_array( $all ) ) {
		$all = array();
	}
	return array_key_exists( $key, $all ) ? $all[ $key ] : ( $defaults[ $key ] ?? null );
}

/** راه‌اندازی اجزا. */
function cbridge_boot() {
	load_plugin_textdomain( 'content-bridge', false, dirname( plugin_basename( CBRIDGE_FILE ) ) . '/languages' );

	CBridge_Rest::init();
	CBridge_Ajax::init();
	CBridge_Faq::init();

	if ( is_admin() ) {
		CBridge_Admin::init();
	}
}
add_action( 'plugins_loaded', 'cbridge_boot' );

/** فعال‌سازی: جدول لاگ + گزینه‌های پیش‌فرض. */
function cbridge_activate() {
	CBridge_Log::install_table();

	$existing = get_option( 'cbridge_settings' );
	if ( ! is_array( $existing ) ) {
		add_option( 'cbridge_settings', cbridge_defaults() );
	}
	add_option( 'cbridge_db_version', CBRIDGE_VERSION );
}
register_activation_hook( __FILE__, 'cbridge_activate' );

/** غیرفعال‌سازی: فقط زمان‌بندی‌ها. داده‌ها در uninstall پاک می‌شوند. */
function cbridge_deactivate() {
	wp_clear_scheduled_hook( 'cbridge_prune_logs' );
}
register_deactivation_hook( __FILE__, 'cbridge_deactivate' );

/** هرس روزانه‌ی لاگ. */
add_action( 'init', function () {
	if ( ! wp_next_scheduled( 'cbridge_prune_logs' ) ) {
		wp_schedule_event( time() + HOUR_IN_SECONDS, 'daily', 'cbridge_prune_logs' );
	}
} );
add_action( 'cbridge_prune_logs', array( 'CBridge_Log', 'prune' ) );

/** ارتقای جدول در صورت تغییر نسخه. */
add_action( 'plugins_loaded', function () {
	if ( get_option( 'cbridge_db_version' ) !== CBRIDGE_VERSION ) {
		CBridge_Log::install_table();
		update_option( 'cbridge_db_version', CBRIDGE_VERSION );
	}
}, 20 );

/** لینک «تنظیمات» در فهرست افزونه‌ها. */
add_filter( 'plugin_action_links_' . plugin_basename( __FILE__ ), function ( $links ) {
	$url = admin_url( 'admin.php?page=content-bridge' );
	array_unshift( $links, '<a href="' . esc_url( $url ) . '">' . esc_html__( 'تنظیمات', 'content-bridge' ) . '</a>' );
	return $links;
} );
